package cs3500.pa03.model;

/**
 * The Coord class represents a coordinate with x and y values.
 */
public class Coord {
  private final int xvalue;
  private final int yvalue;

  /**
   * Constructs a Coord object with the specified x and y values.
   *
   * @param x the x-coordinate
   * @param y the y-coordinate
   */
  public Coord(int x, int y) {
    this.xvalue = x;
    this.yvalue = y;
  }

  /**
   * Retrieves the x-coordinate.
   *
   * @return the x-coordinate
   */
  public int getXvalue() {
    return this.xvalue;
  }

  /**
   * Retrieves the y-coordinate.
   *
   * @return the y-coordinate
   */
  public int getYvalue() {
    return  this.yvalue;
  }

  /**
   * Checks if this Coord is equal to another object.
   *
   * @param o the object to compare with
   * @return true if the objects are equal, false otherwise
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }

    if (!(o instanceof Coord)) {
      return false;
    }

    Coord coord = (Coord) o;

    return this.getXvalue() == coord.getXvalue() && this.getYvalue() == coord.getYvalue();
  }
}
