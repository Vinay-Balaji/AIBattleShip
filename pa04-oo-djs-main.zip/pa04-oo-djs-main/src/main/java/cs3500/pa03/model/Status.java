package cs3500.pa03.model;

/**
 * The Status enum represents the possible statuses of a cell in a game.
 */
public enum Status {
  HIT,
  MISS,
  SHIP,
  EMPTY
}
