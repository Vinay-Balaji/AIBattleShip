package cs3500.pa03.model;

import cs3500.pa03.view.CoordInput;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * The HumanPlayer class represents a human player in the game.
 */
public class HumanPlayer extends AbstractPlayer implements Player {

  private CoordInput coordInput;

  /**
   * Constructs a HumanPlayer with the specified board height,
   * board width, and coordinate input strategy.
   *
   * @param boardHeight the height of the game board
   * @param boardWidth the width of the game board
   * @param coordInput the strategy for obtaining coordinate inputs from the human player
   */
  public HumanPlayer(int boardHeight, int boardWidth, CoordInput coordInput) {
    super(boardHeight, boardWidth);
    this.shots = new ArrayList<>();
    this.shipList = new ArrayList<>();
    this.numShipsRemaining = 0;
    this.coordInput = coordInput;
  }

  /**
   * Get the player's name.
   *
   * @return the player's name
   */
  @Override
  public String name() {
    return "HUMAN";
  }

  /**
   * Returns this player's shots on the opponent's board. The number of shots returned should
   * equal the number of ships on this player's board that have not sunk.
   *
   * @return the locations of shots on the opponent's board
   */
  @Override
  public List<Coord> takeShots() {
    ArrayList<Coord> shots = new ArrayList<>();
    boolean errorMessage = false;
    while (shots.size() < this.numShipsRemaining) {
      //gets prompt
      this.coordInput.enterCoordsPrompt(this.numShipsRemaining, errorMessage);
      shots.clear();
      for (int i = 0; i < this.numShipsRemaining; i++) {
        //checks if input is valid
        if (this.coordInput.receiveCoordInput(new InputStreamReader(System.in))) {
          shots.add(this.coordInput.getCoord());
        } else {
          errorMessage = true;
        }
      }
    }
    // once valid set list to shots field
    this.shots = shots;
    return this.shots;
  }


}
