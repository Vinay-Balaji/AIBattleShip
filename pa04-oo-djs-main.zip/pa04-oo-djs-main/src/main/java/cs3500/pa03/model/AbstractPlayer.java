package cs3500.pa03.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The AbstractPlayer class provides a base implementation for a player in the game.
 */
public abstract class AbstractPlayer implements Player {
  protected int boardHeight;
  protected int boardWidth;

  public ArrayList<Coord> shots;

  protected ShipsBoard shipsBoard;
  protected FeedbackBoard feedbackBoard;

  protected ArrayList<Ship> shipList;

  protected int numShipsRemaining;

  List<Coord> successfulShots = new ArrayList<>();


  /**
   * Constructs an AbstractPlayer with the specified board height and board width.
   *
   * @param boardHeight the height of the game board
   * @param boardWidth the width of the game board
   */
  AbstractPlayer(int boardHeight, int boardWidth) {
    this.boardHeight = boardHeight;
    this.boardWidth = boardWidth;
    this.shots = new ArrayList<>();
    this.shipList = new ArrayList<>();
    this.numShipsRemaining = 0;
  }

  /**
   * Get the player's name.
   *
   * @return the player's name
   */
  public abstract String name();

  /**
   * Given the specifications for a BattleSalvo board, return a list of ships with their locations
   * on the board.
   *
   * @param height         the height of the board, range: [6, 15] inclusive
   * @param width          the width of the board, range: [6, 15] inclusive
   * @param specifications a map of ship type to the number of occurrences each ship should
   *                       appear on the board
   * @return the placements of each ship on the board
   */
  public List<Ship> setup(int height, int width, Map<ShipType, Integer> specifications) {
    // set up shipList object
    ShipList shipList = new ShipList(height, width, specifications);
    shipList.generateShipsPositionList();
    // set up shipsBoard object
    this.shipsBoard = new ShipsBoard(height, width, shipList.getShipPositions());
    this.shipsBoard.setSelfVersionBoard();
    // set up feedbackBoard object
    this.feedbackBoard = new FeedbackBoard(height, width);
    this.feedbackBoard.setUp();
    this.shipList = shipList.getShipList();
    this.numShipsRemaining = this.shipList.size();
    return this.shipList;
  }

  /**
   * Returns this player's shots on the opponent's board. The number of shots returned should
   *equal the number of ships on this player's board that have not sunk.
   *
   * @return the locations of shots on the opponent's board
   */
  public abstract List<Coord> takeShots();

  /**
   * Given the list of shots the opponent has fired on this player's board, report which
   * shots hit a ship on this player's board.
   *
   * @param opponentShotsOnBoard the opponent's shots on this player's board
   * @return list of shots that contain all locations of shots that hit a ship on this board
   */
  public List<Coord> reportDamage(List<Coord> opponentShotsOnBoard) {
    for (Coord coord : opponentShotsOnBoard) {
      boolean remove = false;
      Ship removeShip = null;
      for (Ship ship : this.shipList) {
        //removes coord from ship that got hit
        ship.removeCoord(coord);
        //checks if ship has no coords meaning it has been sunk
        if (ship.getShipCoords().isEmpty()) {
          remove = true;
          removeShip = ship;
        }
      }
      if (remove) {
        //if ship is empty with no coords then remove ship
        this.shipList.remove(removeShip);
      }
    }
    this.numShipsRemaining = this.shipList.size();
    return this.shipsBoard.receiveShots(opponentShotsOnBoard);
  }


  /**
   * Reports to this player what shots in their previous volley returned from takeShots()
   * successfully hit an opponent's ship.
   *
   * @param shotsThatHitOpponentShips the list of shots that successfully hit the opponent's ships
   */

  public void successfulHits(List<Coord> shotsThatHitOpponentShips) {
    this.feedbackBoard.updateShots(shotsThatHitOpponentShips, this.shots);
    this.successfulShots.addAll(shotsThatHitOpponentShips);
  }

  /**
   * Notifies the player that the game is over.
   * Win, lose, and draw should all be supported
   *
   * @param result if the player has won, lost, or forced a draw
   * @param reason the reason for the game ending
   */

  public void endGame(GameResult result, String reason) {
    switch (result) {
      case WIN -> System.out.println(this.name() + " won the game! Reason: " + reason);
      case LOSE -> System.out.println(this.name() + " lost the game! Reason: " + reason);
      case DRAW -> System.out.println("The game was a draw! Reason: " + reason);
      default -> System.out.println("Unknown game result: " + result);
    }
  }


  public Cell[][] getShipBoardData() {
    return this.shipsBoard.getSelfVersionBoard();
  }

  public Cell[][] getFeedbackBoardData() {
    return this.feedbackBoard.getFeedbackBoard();
  }

  public List<Ship> getShipList() {
    return this.shipList;
  }
}
