package cs3500.pa03.model;

import java.util.List;

/**
 * The FeedbackBoard class represents a board that provides
 * feedback on shots fired during the game.
 */
public class FeedbackBoard {
  private final int boardHeight;
  private final int boardWidth;
  private Cell[][] feedbackBoard;


  /**
   * Constructs a FeedbackBoard with the specified board height and width.
   *
   * @param boardHeight the height of the feedback board
   * @param boardWidth the width of the feedback board
   */
  FeedbackBoard(int boardHeight, int boardWidth) {
    this.boardHeight = boardHeight;
    this.boardWidth = boardWidth;
    this.feedbackBoard = new Cell[this.boardHeight][this.boardWidth];
  }

  /**
   * Sets up the initial state of the feedback board.
   */
  public void setUp() {
    for (int i = 0; i < this.boardHeight; i++) {
      for (int j = 0; j < this.boardWidth; j++) {
        this.feedbackBoard[i][j] = new Cell();
      }
    }
  }

  /**
   * Updates the feedback board based on the shots fired during the game.
   *
   * @param shotsThatHitOpponentShips the list of coordinates where shots hit opponent ships
   * @param allShots the list of all shots fired during the game
   */
  public void updateShots(List<Coord> shotsThatHitOpponentShips, List<Coord> allShots) {
    for (Coord coord : allShots) {
      //if it is a successful shot then set the coordinate to hit
      if (shotsThatHitOpponentShips.contains(coord)) {
        this.feedbackBoard[coord.getYvalue()][coord.getXvalue()].setHit();
      } else {
        this.feedbackBoard[coord.getYvalue()][coord.getXvalue()].setMiss();
      }
    }
  }

  /**
   * Retrieves the feedback board.
   *
   * @return the feedback board as a 2D array of Cell objects
   */
  public Cell[][] getFeedbackBoard() {
    return this.feedbackBoard;
  }
}
