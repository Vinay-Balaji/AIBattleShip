package cs3500.pa03.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The ComputerPlayer class represents a computer player in the game.
 */
public class ComputerPlayer extends AbstractPlayer implements Player {


  List<Coord> shotsAvailable;

  /**
   * Constructs a ComputerPlayer with the specified board height and board width.
   *
   * @param boardHeight the height of the game board
   * @param boardWidth the width of the game board
   */
  public ComputerPlayer(int boardHeight, int boardWidth) {
    super(boardHeight, boardWidth);
    this.shots = new ArrayList<>();
    this.shipList = new ArrayList<>();
    this.numShipsRemaining = 0;
    this.shotsAvailable = new ArrayList<>();

    for (int i = 0; i < boardWidth; i++) {
      for (int j = 0; j < boardHeight; j++) {
        shotsAvailable.add(new Coord(i, j));
      }
    }
  }

  /**
   * Get the player's name.
   *
   * @return the player's name
   */
  @Override
  public String name() {
    return "COMPUTER";
  }

  /**
   * Returns this player's shots on the opponent's board. The number of shots returned should
   * equal the number of ships on this player's board that have not sunk.
   *
   * @return the locations of shots on the opponent's boards
   */
  @Override
  public List<Coord> takeShots() {
    // Create a new list of coordinates where shots will be taken this round
    List<Coord> roundShots = new ArrayList<>();

    // The number of shots to be taken is the minimum of the number of remaining ships
    // and available shots
    int numberOfShots = Math.min(this.shipList.size(), this.shotsAvailable.size());

    // Loop through for the number of shots to be taken
    for (int i = 0; i < numberOfShots; i++) {
      // Get a targeted shot (a coordinate next to a successful previous shot)
      Coord shot = getTargetedShot();

      // If no targeted shots available, resort to random shots
      if (shot == null) {
        // Create a new Random object
        Random random = new Random();
        // Select a random index from the list of available shots
        int nextIndex = random.nextInt(this.shotsAvailable.size());
        // Remove the shot at the selected index from available shots,
        // and set it as the shot to be taken
        shot = this.shotsAvailable.remove(nextIndex);
      }
      // Add the selected shot to the list of shots to be taken this round
      roundShots.add(shot);
    }
    // Return the list of shots to be taken this round
    return roundShots;
  }

  /**
   * Method to get targetd shot based on previous successfull hits
   *
   * @return - the targeted shot coordinate
   */
  private Coord getTargetedShot() {
    // Iterate over the list of successful shot coordinates
    for (Coord hit : this.successfulShots) {
      // Generate a list of possible shot coordinates adjacent to the successful hit
      List<Coord> possibleShots = getAdjacentCoords(hit);
      // Iterate over the list of possible shot coordinates
      for (Coord shot : possibleShots) {
        // If the shot is in the list of available shots, remove it from the
        // available shots list and return it as the targeted shot
        if (this.shotsAvailable.remove(shot)) {
          return shot;
        }
      }
    }
    return null;
  }

  /**
   * Method to get a list of coordinates adjacent to a given coordinate
   *
   * @param coord - a coordinate
   * @return - a list of adjacent coordinates
   */
  private List<Coord> getAdjacentCoords(Coord coord) {
    // Initializing an ArrayList to store the adjacent coordinates
    List<Coord> adjacentCoords = new ArrayList<>();
    // Adding the coordinate to the right of the given coordinate to the list
    adjacentCoords.add(new Coord(coord.getXvalue() + 1, coord.getYvalue()));
    // Adding the coordinate to the left of the given coordinate to the list
    adjacentCoords.add(new Coord(coord.getXvalue() - 1, coord.getYvalue()));
    // Adding the coordinate above the given coordinate to the list
    adjacentCoords.add(new Coord(coord.getXvalue(), coord.getYvalue() + 1));
    // Adding the coordinate below the given coordinate to the list
    adjacentCoords.add(new Coord(coord.getXvalue(), coord.getYvalue() - 1));
    // Returning the list of adjacent coordinates
    return adjacentCoords;
  }
}