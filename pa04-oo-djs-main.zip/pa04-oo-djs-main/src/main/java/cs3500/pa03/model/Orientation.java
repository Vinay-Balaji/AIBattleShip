package cs3500.pa03.model;

/**
 * Orientation Enum
 */
public enum Orientation {
  VERTICAL,
  HORIZONTAL
}
