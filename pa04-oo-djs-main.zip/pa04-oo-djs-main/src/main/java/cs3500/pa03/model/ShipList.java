package cs3500.pa03.model;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

/**
 * The ShipList class represents a collection of ships in the game.
 */
public class ShipList {
  private final int boardWidth;
  private final int boardHeight;

  private final Map<ShipType, Integer> specifications;

  private ArrayList<Coord> shipPositions;

  private ArrayList<Ship> shipList;

  private Random random = new Random();

  /**
   * Constructs a ShipList with the specified board width, board height, and ship specifications.
   *
   * @param boardWidth the width of the game board
   * @param boardHeight the height of the game board
   * @param specifications  the specifications for the ships in the form of a map,
   *                        mapping each ship type to its quantity
   */
  ShipList(int boardWidth, int boardHeight, Map<ShipType, Integer> specifications) {
    this.boardWidth = boardWidth;
    this.boardHeight = boardHeight;
    this.specifications = specifications;
    this.shipPositions = new ArrayList<>();
    this.shipList = new ArrayList<>();
  }


  /**
   * Generates the list of ship positions based on the ship specifications.
   */
  public void generateShipsPositionList() {
    int numberOfCarriers = this.specifications.get(ShipType.CARRIER);
    int numberOfBattleShips = this.specifications.get(ShipType.BATTLESHIP);
    int numberOfDestroyers = this.specifications.get(ShipType.DESTROYER);
    int numberOfSubmarines = this.specifications.get(ShipType.SUBMARINE);
    this.generateShipList(ShipType.CARRIER, numberOfCarriers);
    this.generateShipList(ShipType.BATTLESHIP, numberOfBattleShips);
    this.generateShipList(ShipType.DESTROYER, numberOfDestroyers);
    this.generateShipList(ShipType.SUBMARINE, numberOfSubmarines);

  }

  /**
   * Generates ship instances of the specified ship type and adds them to the ship list.
   *
   * @param shipType shipType the type of ship to generate
   * @param amount amount the number of ships to generate
   */
  public void generateShipList(ShipType shipType, int amount) {

    for (int i = 0; i < amount; i++) {
      while (true) {
        ArrayList<Coord> coordArrayList = new ArrayList<>();
        Ship ship;
        // true will indicate a horizontal ship
        if (random.nextBoolean()) {
          ship = new Ship(Orientation.HORIZONTAL);
          //gets starting x coordinate of ship
          int x = Math.abs(random.nextInt()) % (this.boardHeight - shipType.getSize() + 1);
          //gets starting y coordinate of ship
          int y = Math.abs(random.nextInt()) % this.boardWidth;
          for (int j = 0; j < shipType.getSize(); j++) {
            //adds corresponding ship coordinates to list
            coordArrayList.add(new Coord(x + j, y));
          }
        } else {
          ship = new Ship(Orientation.VERTICAL);
          //gets starting x coordinate of ship
          int x = Math.abs(random.nextInt()) % this.boardHeight;
          //gets starting y coordinate of ship
          int y = Math.abs(random.nextInt()) % (this.boardWidth - shipType.getSize() + 1);
          for (int k = 0; k < shipType.getSize(); k++) {
            //adds corresponding ship coordinates to list
            coordArrayList.add(new Coord(x, y + k));
          }
        }
        //checks if this ship overlaps other previously initialized ships
        boolean repeat = false;
        for (Coord coordLocal : coordArrayList) {
          for (Coord coordGlobal : this.shipPositions) {
            if (coordLocal.equals(coordGlobal)) {
              repeat = true;
            }
          }
        }
        // if the ship doesn't overlap then loop breaks
        if (!repeat) {
          this.shipPositions.addAll(coordArrayList);
          ship.addListCoord(coordArrayList);
          this.shipList.add(ship);
          break;
        }
      }
    }
  }

  /**
   * Retrieves the list of ship positions.
   *
   * @return the list of ship positions as an ArrayList of Coord objects
   */
  public ArrayList<Coord> getShipPositions() {
    return this.shipPositions;
  }

  /**
   * Retrieves the list of ships.
   *
   * @return the list of ships as an ArrayList of Ship objects
   */
  public ArrayList<Ship> getShipList() {
    return this.shipList;
  }
}
