package cs3500.pa03.model;

/**
 * The GameResult enum represents the possible results of a game.
 */
public enum GameResult {
  WIN,
  LOSE,
  DRAW
}
