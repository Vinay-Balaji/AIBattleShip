package cs3500.pa03.model;

/**
 * The ShipType enum represents different types of ships in a game.
 */
public enum ShipType {
  CARRIER(6),
  BATTLESHIP(5),
  DESTROYER(4),
  SUBMARINE(3),
  ;

  final int size;

  /**
   * Constructs a ShipType with the specified size.
   *
   * @param size the size of the ship
   */
  ShipType(int size) {
    this.size = size;
  }


  /**
   * Retrieves the size of the ship.
   *
   * @return the size of the ship
   */
  int getSize() {
    return size;
  }
}
