package cs3500.pa03.model;

import java.util.ArrayList;
import java.util.List;

/**
 * The ShipsBoard class represents a game board for tracking ship positions and hit/miss statuses.
 */
public class ShipsBoard {
  private final int boardHeight;
  private final int boardWidth;
  private Cell[][] selfVersionBoard;

  private ArrayList<Coord> shipCoordList;

  /**
   * Constructs a ShipsBoard with the specified board height, width, and ship coordinate list.
   *
   * @param boardHeight the height of the game board
   * @param boardWidth the width of the game board
   * @param shipCoordList the list of coordinates where ships are placed on the board
   */
  ShipsBoard(int boardHeight, int boardWidth, ArrayList<Coord> shipCoordList) {
    this.boardHeight = boardHeight;
    this.boardWidth = boardWidth;
    this.shipCoordList = shipCoordList;
    this.selfVersionBoard = new Cell[this.boardHeight][this.boardWidth];
  }

  /**
   * Sets up the self version of the game board by
   * populating the cells with ship and empty statuses.
   */
  public void setSelfVersionBoard() {
    for (int i = 0; i < this.boardHeight; i++) {
      for (int j = 0; j < this.boardWidth; j++) {
        if (this.hasShip(new Coord(j, i))) {
          // if it has ship set cell status to ship
          this.selfVersionBoard[i][j] = new Cell(Status.SHIP);
        } else {
          // else set the cell to empty
          this.selfVersionBoard[i][j] = new Cell();
        }
      }
    }
  }

  /**
   * Checks if a cell at the specified coordinate contains a ship.
   *
   * @param coord  the coordinate to check
   * @return true if the cell contains a ship, false otherwise
   */
  public boolean hasShip(Coord coord) {
    for (Coord c : this.shipCoordList) {
      //checks if coordinate c has ship
      if (coord.equals(c)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Receives a list of shots and updates the board based on the results.
   *
   * @param shots the list of coordinates representing the shots fired
   * @return a list of coordinates that were hit by the shots
   */
  public List<Coord> receiveShots(List<Coord> shots) {
    List<Coord> shotsHit = new ArrayList<>();
    for (Coord coord : shots) {
      if (this.hasShip(coord)) {
        //if a shot coord has a ship, set the coord to hit
        this.selfVersionBoard[coord.getYvalue()][coord.getXvalue()].setHit();
        //add coord to coord list of hit shots
        shotsHit.add(coord);
      } else {
        //if a shot coord doesn't have a ship, set the coord to miss
        this.selfVersionBoard[coord.getYvalue()][coord.getXvalue()].setMiss();
      }
    }
    return shotsHit;
  }


  /**
   * Retrieves the self version of the game board.
   *
   * @return the two-dimensional array of cells representing the current state of the board
   */
  public Cell[][] getSelfVersionBoard() {
    return this.selfVersionBoard;
  }
}
