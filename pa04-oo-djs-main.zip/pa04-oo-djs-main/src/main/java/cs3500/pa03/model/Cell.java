package cs3500.pa03.model;

/**
 * The Cell class represents a cell on a game board.
 */
public class Cell {
  private Status status;

  /**
   * Constructs an empty Cell with the default status of EMPTY.
   */
  public Cell() {
    this.status = Status.EMPTY;
  }

  /**
   * Constructs a Cell with the specified status.
   *
   * @param status the status of the cell
   */
  public Cell(Status status) {
    this.status = status;
  }

  /**
   * Sets the status of the cell to HIT.
   */
  public void setHit() {
    this.status = Status.HIT;
  }

  /**
   * Sets the status of the cell to MISS.
   */
  public void setMiss() {
    this.status = Status.MISS;
  }

  /**
   * Retrieves the status of the cell.
   *
   * @return the status of the cell
   */
  public Status getStatus() {
    return this.status;
  }
}
