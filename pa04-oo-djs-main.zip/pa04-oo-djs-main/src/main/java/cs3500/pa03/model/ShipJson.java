package cs3500.pa03.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ShipJson record
 *
 * @param coord - coordinate
 */
public record ShipJson(
    @JsonProperty("Coord") Coord coord) {

}
