package cs3500.pa03.model;

import java.util.ArrayList;

/**
 * The Ship class represents a ship in the game.
 */
public class Ship {
  private ArrayList<Coord> shipCoords;
  private Orientation orientation;

  /**
   * Constructs an empty Ship object.
   */
  Ship(Orientation orientation) {

    this.shipCoords = new ArrayList<>();
    this.orientation = orientation;
  }

  /**
   * Adds a list of coordinates to the ship's coordinate list.
   *
   * @param coordList the list of coordinates to add
   */
  public void addListCoord(ArrayList<Coord> coordList) {

    this.shipCoords.addAll(coordList);
  }

  /**
   * Retrieves the list of coordinates that make up the ship's position.
   *
   * @return the list of ship coordinates as an ArrayList of Coord objects
   */
  public ArrayList<Coord> getShipCoords() {

    return shipCoords;
  }

  /**
   * Removes a specified coordinate from the ship's coordinate list.
   *
   * @param coord the coordinate to remove
   */
  public void removeCoord(Coord coord) {
    this.shipCoords.remove(coord);
  }

  public Orientation getOrientation() {
    return this.orientation;
  }

}
