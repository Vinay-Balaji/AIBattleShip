package cs3500.pa03.controller;

import cs3500.pa03.model.ComputerPlayer;
import cs3500.pa03.model.Coord;
import cs3500.pa03.model.GameResult;
import cs3500.pa03.model.HumanPlayer;
import cs3500.pa03.model.ShipType;
import cs3500.pa03.view.CoordInput;
import cs3500.pa03.view.OutputLabels;
import cs3500.pa03.view.OutputResultLabels;
import cs3500.pa03.view.OutputShipBoard;
import cs3500.pa03.view.ShipsInput;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Controller class handles the logic of the game and coordinates
 * the interactions between players and views.
 */
public class Controller {

  protected HumanPlayer humanPlayer;
  protected ComputerPlayer computerPlayer;

  /**
   * Constructs a Controller object.
   */
  public Controller() {
    this.humanPlayer = null;
    this.computerPlayer = null;
  }

  /**
   * Starts the game loop and manages the game flow.
   */
  public void gameLoop() {
    ShipsInput shipsInput = new ShipsInput();
    boolean valid = false;
    CoordInput boardSizeInput = new CoordInput(15, 15, 6, 6);
    int counter = 0;
    //loop for checking and taking in valid board size
    while (!valid) {
      OutputLabels.printBoardSizePrompt(counter != 0);
      counter++;
      valid = boardSizeInput.receiveCoordInput(new InputStreamReader(System.in));
    }
    // initializing all objects required to run game
    int width = boardSizeInput.getCoord().getXvalue();
    int height = boardSizeInput.getCoord().getYvalue();
    valid = false;
    counter = 0;
    //loop for checking and taking in valid fleet size
    while (!valid) {
      OutputLabels.printFleetSizePrompt(counter != 0);
      counter++;
      valid = shipsInput.receiveShipInput(new InputStreamReader(System.in), height, width);
    }

    List<Integer> shipInts = shipsInput.getShipList();
    this.initialization(height, width, shipInts.get(0),
        shipInts.get(1), shipInts.get(2), shipInts.get(3));

    // loop for each turn of the game, terminating when checkEnd method returns true
    boolean endGame = false;
    while (!endGame) {
      this.turn();
      endGame = this.checkEnd();
    }
    OutputResultLabels.resultLabel(this.gameResult());
  }


  /**
   * Executes a single turn of the game.
   */
  public void turn() {
    //prints corresponding labels
    OutputLabels.printOpponentBoardLabel();
    OutputShipBoard.printShipBoard(this.humanPlayer.getFeedbackBoardData());
    OutputLabels.printUserBoardLabel();
    OutputShipBoard.printShipBoard(this.humanPlayer.getShipBoardData());
    //gets shots of both players
    List<Coord> humanShots = this.humanPlayer.takeShots();
    List<Coord> computerShots = this.computerPlayer.takeShots();
    //gets successful shots of each player
    List<Coord> successfulComputerShots = this.humanPlayer.reportDamage(computerShots);
    List<Coord> successfulHumanShots = this.computerPlayer.reportDamage(humanShots);
    // updates feedback board for corresponding players
    this.computerPlayer.successfulHits(successfulComputerShots);
    this.humanPlayer.successfulHits(successfulHumanShots);
  }

  /**
   * Initializes the game by creating the players and setting up the ships.
   *
   * @param height the height of the game board
   * @param width the width of the game board
   * @param carriers the number of carriers
   * @param battleships the number of battleships
   * @param destroyers the number of destroyers
   * @param submarines the number of submarines
   */
  public void initialization(int height, int width, int carriers,
                             int battleships, int destroyers, int submarines) {
    this.humanPlayer = new HumanPlayer(height, width,
        new CoordInput(height, width, 0, 0));
    this.computerPlayer = new ComputerPlayer(height, width);

    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.CARRIER, carriers);
    map.put(ShipType.BATTLESHIP, battleships);
    map.put(ShipType.DESTROYER, destroyers);
    map.put(ShipType.SUBMARINE, submarines);
    this.humanPlayer.setup(height, width, map);
    this.computerPlayer.setup(height, width, map);

  }

  /**
   * Checks if the game has ended.
   *
   * @return true if the game has ended, false otherwise
   */
  public boolean checkEnd() {
    return this.humanPlayer.getShipList().isEmpty() || this.computerPlayer.getShipList().isEmpty();
  }

  /**
   * Determines the result of the game.
   *
   * @return the GameResult indicating the result of the game
   */
  public GameResult gameResult() {
    if (this.humanPlayer.getShipList().isEmpty() && this.computerPlayer.getShipList().isEmpty()) {
      return GameResult.DRAW;
    } else if (this.humanPlayer.getShipList().isEmpty()) {
      return GameResult.LOSE;
    } else if (this.computerPlayer.getShipList().isEmpty()) {
      return GameResult.WIN;
    } else {
      throw new RuntimeException("Error");
    }
  }
}
