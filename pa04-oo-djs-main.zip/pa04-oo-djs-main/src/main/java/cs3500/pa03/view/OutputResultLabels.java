package cs3500.pa03.view;

import cs3500.pa03.model.GameResult;
import java.io.PrintStream;

/**
 * OutputResultLabels class provides a static method to
 * print the result label based on the game outcome.
 */
public class OutputResultLabels {
  /**
   * Prints the result label based on the game outcome.
   *
   * @param gameResult the result of the game
   * @return the PrintStream object for the output
   */
  public static PrintStream resultLabel(GameResult gameResult) {
    if (gameResult.equals(GameResult.WIN)) {
      return System.out.append("YOU WIN");
    } else if (gameResult.equals(GameResult.LOSE)) {
      return System.out.append("YOU LOSE");
    } else {
      return System.out.append("DRAW");
    }

  }
}
