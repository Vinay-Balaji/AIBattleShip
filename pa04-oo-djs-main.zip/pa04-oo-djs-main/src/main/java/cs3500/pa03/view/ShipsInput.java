package cs3500.pa03.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * ShipsInput class represents a user input for ship sizes
 * and provides methods to receive and validate the input.
 */
public class ShipsInput {
  private List<Integer> shipList;

  /**
   * Constructs a ShipsInput object with an empty ship list.
   */
  public ShipsInput() {
    this.shipList = new ArrayList<>();
  }

  /**
   * Receives the ship size input from the user and validates it.
   *
   * @param readable the Readable object from which to read the input
   * @param height height of the board
   * @param width width of the board
   * @return true if the input is valid and successfully received, false otherwise
   */
  public boolean receiveShipInput(Readable readable, int height, int width) {
    Scanner scanner = new Scanner(readable);
    String line = scanner.nextLine();
    Scanner lineScanner = new Scanner(line);
    ArrayList<Integer> ints = new ArrayList<>();
    int sum = 0;
    int numInput;

    // scans input
    while (lineScanner.hasNext()) {
      if (lineScanner.hasNextInt()) {
        numInput = lineScanner.nextInt();
        ints.add(numInput);
        sum = sum + numInput;
      } else {
        lineScanner.next();
      }
    }
    this.shipList = ints;
    // checks if the input is valid
    if (sum > 8) {
      return false;
    }
    if (ints.size() != 4) {
      return false;
    }
    if (sum > height || sum > width) {
      return false;
    }
    return ints.get(0) > 0 && ints.get(1) > 0 && ints.get(2) > 0 && ints.get(3) > 0;
  }


  /**
   * Gets the ship sizes entered by the user.
   *
   * @return the list of ship sizes
   */
  public List<Integer> getShipList() {
    return this.shipList;
  }
}