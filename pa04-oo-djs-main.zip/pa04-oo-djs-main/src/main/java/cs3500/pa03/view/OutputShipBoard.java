package cs3500.pa03.view;

import cs3500.pa03.model.Cell;
import cs3500.pa03.model.Status;
import java.io.PrintStream;

/**
 * OutputShipBoard class provides a static method to print the ship board representation.
 */
public class OutputShipBoard {

  /**
   * Prints the ship board representation.
   *
   * @param shipBoard the ship board to be printed
   * @return the PrintStream object for the output
   */
  public static PrintStream printShipBoard(Cell[][] shipBoard) {
    for (Cell[] cells : shipBoard) {
      for (Cell cell : cells) {
        if (cell.getStatus().equals(Status.SHIP)) {
          System.out.append("S ");
        } else if (cell.getStatus().equals(Status.HIT)) {
          System.out.append("H ");
        } else if (cell.getStatus().equals(Status.MISS)) {
          System.out.append("M ");
        } else {
          System.out.append("0 ");
        }
      }
      System.out.append("\n");
    }
    return System.out.append("\n");
  }
}
