package cs3500.pa03.view;

import cs3500.pa03.model.Coord;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The CoordInput class represents a user input for coordinates
 * and provides methods to receive and validate the input.
 */
public class CoordInput {
  private Coord coord;
  private final int maxHeight;
  private final int maxWidth;

  private final int minHeight;
  private final int minWidth;

  /**
   * Constructs a CoordInput object with the specified maximum and minimum height and width values.
   *
   * @param maxHeight the maximum height value allowed for the coordinates
   * @param maxWidth the maximum width value allowed for the coordinates
   * @param minHeight the minimum height value allowed for the coordinates
   * @param minWidth the minimum width value allowed for the coordinates
   */
  public CoordInput(int maxHeight, int maxWidth, int minHeight, int minWidth) {
    this.coord = null;
    this.maxHeight = maxHeight;
    this.maxWidth = maxWidth;
    this.minHeight = minHeight;
    this.minWidth = minWidth;
  }

  /**
   * Receives the coordinate input from the user and validates it.
   *
   * @param readable the Readable object from which to read the input
   * @return true if the input is valid and successfully received, false otherwise
   */
  public boolean receiveCoordInput(Readable readable) {
    Scanner scanner = new Scanner(readable);
    String line = scanner.nextLine();
    Scanner lineScanner = new Scanner(line);
    ArrayList<Integer> ints = new ArrayList<>();
    int numInput;

    while (lineScanner.hasNext()) {
      if (lineScanner.hasNextInt()) {
        numInput = lineScanner.nextInt();
        ints.add(numInput);
      } else {
        lineScanner.next();
      }
    }
    //checks if input is valid
    if (ints.size() != 2) {
      return false;
    }
    if (ints.get(0) > this.maxWidth || ints.get(1) > this.maxHeight
        || ints.get(0) < this.minWidth || ints.get(1) < this.minHeight) {
      return false;
    }

    this.coord = new Coord(ints.get(0), ints.get(1));

    return true;

  }

  /**
   * Prints the prompt for entering the coordinates.
   *
   * @param numberShots the number of coordinate pairs to enter
   * @param invalid indicates if the previous input was invalid
   * @return the PrintStream object used for printing the prompt
   */
  public PrintStream enterCoordsPrompt(int numberShots, boolean invalid) {
    if (invalid) {
      errorCoordsPrompt();
      return System.out.append("Enter " + numberShots + " coordinate pairs: \n");
    } else {
      return System.out.append("Enter " + numberShots + " coordinate pairs: \n");
    }

  }

  /**
   * Prints the error prompt for invalid coordinate input.
   *
   * @return the PrintStream object used for printing the error prompt
   */
  public PrintStream errorCoordsPrompt() {
    return System.out.append("Try Again Follow the Correct Format\n");
  }

  /**
   * Gets the coordinate entered by the user.
   *
   * @return the Coord object representing the entered coordinates
   */
  public Coord getCoord() {
    return this.coord;
  }
}
