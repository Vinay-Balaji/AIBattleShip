package cs3500.pa03.view;

import java.io.PrintStream;

/**
 * OutputLabels class provides static methods to print
 * various labels and prompts for the game output.
 */
public class OutputLabels {
  /**
   * Prints the label for the opponent's board data.
   *
   * @return the PrintStream object for the output
   */
  public static PrintStream printOpponentBoardLabel() {
    return System.out.append("Opponent Board Data:\n");
  }

  /**
   * Prints the label for the user's board.
   *
   * @return the PrintStream object for the output
   */
  public static PrintStream printUserBoardLabel() {
    return System.out.append("Your Board:\n");
  }

  /**
   * Prints the prompt for entering the board size.
   *
   * @param invalid flag indicating if the previous input was invalid
   * @return the PrintStream object for the output
   */
  public static PrintStream printBoardSizePrompt(boolean invalid) {
    if (invalid) {
      printInvalidBoardSizePrompt();
      return System.out.append("Please enter a valid height and width below:\n");
    } else {
      return System.out.append("Please enter a valid height and width below:\n");
    }

  }

  /**
   * Prints the prompt for entering an invalid board size.
   *
   * @return the PrintStream object for the output
   */
  public static PrintStream printInvalidBoardSizePrompt() {
    return System.out.append("Uh Oh! You've entered invalid dimensions."
        + " Please remember that the height and width\n"
        + "of the game must be in the range (6, 10), inclusive. Try again!\n");
  }

  /**
   * Prints the prompt for entering the fleet size.
   *
   * @param invalid flag indicating if the previous input was invalid
   * @return the PrintStream object for the output
   */
  public static PrintStream printFleetSizePrompt(boolean invalid) {
    if (invalid) {
      printInvalidFleetSizePrompt();
      return System.out.append("Please enter your fleet in the order "
          + "[Carrier, Battleship, Destroyer, Submarine].\n"
          + "Remember, your fleet may not exceed size 8.\n");
    }
    return System.out.append("Please enter your fleet in the order "
        + "[Carrier, Battleship, Destroyer, Submarine].\n"
        + "Remember, your fleet may not exceed size 8.\n");
  }

  /**
   * Prints the prompt for entering an invalid fleet size.
   *
   * @return the PrintStream object for the output
   */
  public static PrintStream printInvalidFleetSizePrompt() {
    return System.out.append("Uh Oh! You've entered invalid fleet sizes.\n");
  }
}
