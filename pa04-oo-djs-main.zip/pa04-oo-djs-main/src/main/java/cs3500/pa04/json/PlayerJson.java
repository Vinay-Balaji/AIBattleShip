package cs3500.pa04.json;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a JSON object that contains player information.
 *
 * @param name - the player's name
 * @param gameType - the player's game type
 */
public record PlayerJson(
    @JsonProperty("name") String name,
    @JsonProperty("game-type") String gameType
) {

  /**
   * Returns the name of the player
   *
   * @return - the name of the player
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the game-type of the player
   *
   * @return - the game-type of the player
   */
  public String getGameType() {
    return gameType;
  }
}
