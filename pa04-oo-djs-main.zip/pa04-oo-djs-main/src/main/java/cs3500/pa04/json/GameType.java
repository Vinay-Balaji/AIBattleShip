package cs3500.pa04.json;

/**
 * Represents the game type in a JSON object.
 */
public enum GameType {
  SINGLE,
  MUTLI
}
