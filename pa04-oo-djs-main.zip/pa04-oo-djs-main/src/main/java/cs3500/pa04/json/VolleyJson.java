package cs3500.pa04.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Returns the list of shot coordinates in the volley.
 *
 * @param shots - the list of shot coordinates
 */
public record VolleyJson(@JsonProperty("coordinates") List<CoordJson> shots) {
  public List<CoordJson> getCoordinates() {
    return shots;
  }
}
