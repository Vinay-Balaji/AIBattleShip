package cs3500.pa04.json;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a JSON coordinate object with x and y values.
 *
 * @param x - x coordinate value
 * @param y - y coordinate value
 */
public record CoordJson(@JsonProperty("x") int x,  @JsonProperty("y") int y) {

  /**
   * Returns the x coordinate value
   *
   * @return - the x coordinate
   */
  public int getX() {
    return x;
  }

  /**
   * Returns the y coordinate value
   *
   * @return - the y coordinate
   */
  public int getY() {
    return y;
  }
}
