package cs3500.pa04.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import cs3500.pa03.model.ShipType;
import java.util.Map;

/**
 * Represents a JSON object that contains setup information for a game.
 *
 * @param width - the width of the game board
 * @param height - the height of the game board
 * @param fleetSpec - Returns the fleet specification, which maps ship types to their counts.
 */
public record SetUpJson(
    @JsonProperty("width") int width,
    @JsonProperty("height") int height,
    @JsonProperty("fleet-spec") Map<ShipType, Integer> fleetSpec
) {

}
