package cs3500.pa04.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Returns the fleet of ships
 *
 * @param fleet - the fleet of ships
 */
public record FleetJson(@JsonProperty ("fleet") List<ShipJson> fleet) {
  public List<ShipJson> getFleet() {
    return fleet;
  }
}
