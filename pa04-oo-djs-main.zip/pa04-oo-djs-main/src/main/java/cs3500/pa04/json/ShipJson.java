package cs3500.pa04.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import cs3500.pa03.model.Orientation;

/**
 * Represents a JSON object that contains ship information.
 *
 * @param coord - returns the coordinate of the ship
 * @param length - returns the length of the ship
 * @param direction - returns the direction of the ship
 */
public record ShipJson(
    @JsonProperty("coord") CoordJson coord,
    @JsonProperty("length") int length,
    @JsonProperty("direction") Orientation direction
) {

  /**
   * Returns the coordinate of the ship
   *
   * @return - the coordinate of the ship
   */
  public CoordJson getCoord() {
    return coord;
  }

  /**
   * Returns the length of the ship
   *
   * @return - the length of the ship
   */
  public int getLength() {
    return length;
  }

  /**
   * Returns the direction of the ship.
   *
   * @return - the direction of the ship
   */
  public Orientation getDirection() {
    return direction;
  }
}
