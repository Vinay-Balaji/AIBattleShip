package cs3500.pa04.proxyController;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cs3500.pa03.model.ComputerPlayer;
import cs3500.pa03.model.Coord;
import cs3500.pa03.model.GameResult;
import cs3500.pa03.model.Orientation;
import cs3500.pa03.model.Player;
import cs3500.pa03.model.Ship;
import cs3500.pa03.model.ShipType;
import cs3500.pa04.json.CoordJson;
import cs3500.pa04.json.FleetJson;
import cs3500.pa04.json.GameType;
import cs3500.pa04.json.JsonUtils;
import cs3500.pa04.json.MessageJson;
import cs3500.pa04.json.PlayerJson;
import cs3500.pa04.json.SetUpJson;
import cs3500.pa04.json.ShipJson;
import cs3500.pa04.json.VolleyJson;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ProxyController serves as a controller for the game, managing the interactions
 * between the Player and the server.
 */
public class ProxyController implements ControllerInterface {

  private final Socket server;
  private final InputStream in;
  private final PrintStream out;
  private Player player;
  private final ObjectMapper mapper = new ObjectMapper();
  private final GameType gametype;

  private static final JsonNode VOID_RESPONSE =
      new ObjectMapper().getNodeFactory().textNode("void");

  /**
   * Instantiates a new Proxy controller
   *
   * @param server - the server socket
   * @param gametype - the type of game (Ex. Single, Multiplayer)
   * @throws IOException - if an i/o error occurs when opening the socket
   */
  public ProxyController(Socket server, GameType gametype) throws IOException {
    this.server = server;
    this.in = server.getInputStream();
    this.out = new PrintStream(server.getOutputStream());
    this.player = null;
    this.gametype = gametype;
  }

  /**
   * Listens for messages from the server as JSON in the format of a MessageJSON. When a complete
   * message is sent by the server, the message is parsed and then delegated to the corresponding
   * helper method for each message. This method stops when the connection to the server is closed
   * or an IOException is thrown from parsing malformed JSON.
   */
  public void run() {
    // Create a new JSON parser from the input stream of the server.
    try {
      JsonParser parser = this.mapper.getFactory().createParser(this.in);

      // While the server connection is still open, continue to read messages.
      while (!this.server.isClosed()) {
        // Read the next JSON message from the server, converting it into a MessageJson object.
        MessageJson message = parser.readValueAs(MessageJson.class);

        // Delegate the handling of the received message.
        delegateMessage(message);
      }
    } catch (IOException e) {
      // Disconnected from server or parsing exception s
    }
  }


  /**
   * Determines the type of request the server has sent and delegates to the
   * corresponding helper method with the message arguments.
   *
   * @param message the MessageJSON used to determine what the server has sent
   */
  private void delegateMessage(MessageJson message) {
    // Extract the method name from the JSON message.
    String name = message.methodName();
    // Extract the arguments from the JSON message.
    JsonNode arguments = message.arguments();
    // If the method name is "join", delegate handling to the handleJoin method. Same pattern
    // for remaining if statements
    if ("join".equals(name)) {
      handleJoin(arguments);
    } else if ("setup".equals(name)) {
      handleSetUp(arguments);
    } else if ("take-shots".equals(name)) {
      handleTakeShots(arguments);
    } else if ("report-damage".equals(name)) {
      handleReportDamage(arguments);
    } else if ("successful-hits".equals(name)) {
      handleSuccessfulHits(arguments);
    } else if ("end-game".equals(name)) {
      handleEndGame(arguments);
      // If the method name is anything else, throw an exception.
    } else {
      throw new IllegalStateException("Invalid message name");
    }
  }


  /**
   * Parses the given message arguments as a GuessJSON type, asks the player to take a guess given
   * the hint from the server, and then serializes the player's new guess to Json and sends the
   * response to the server.
   *
   * @param arguments the Json representation of a GuessJSON
   */
  private void handleJoin(JsonNode arguments) {
    // Convert the JsonNode arguments to PlayerJson object using the ObjectMapper.
    PlayerJson args = this.mapper.convertValue(arguments, PlayerJson.class);

    // Define a fixed player name.
    String name = "jackyu000";

    // Create a PlayerJson object for the response using the player name and a single game type
    PlayerJson response = new PlayerJson(name, "SINGLE");

    // Convert the PlayerJson object to a JsonNode using serializeRecord from JsonUtils.
    JsonNode jsonArgument = JsonUtils.serializeRecord(response);

    // Create a MessageJson object with the method name "join"
    MessageJson messageJson = new MessageJson("join", jsonArgument);

    // Convert the MessageJson object to a JsonNode.
    JsonNode jsonResponse = JsonUtils.serializeRecord(messageJson);

    // Print the JSON response to the output stream (send it to the server).
    this.out.println(jsonResponse);
  }

  /**
   * Handles the "setup" server message. The player sets up its fleet of ships.
   *
   * @param arguments - Json Arguments for the setup method
   */
  private void handleSetUp(JsonNode arguments) {
    // Convert the JsonNode arguments to a SetUpJson object using the ObjectMapper.
    SetUpJson args = this.mapper.convertValue(arguments, SetUpJson.class);

    // Extract the width and height of the game board from the SetUpJson object.
    int width = args.width();
    int height = args.height();

    // Create a new ComputerPlayer with the received board dimensions
    this.player = new ComputerPlayer(height, width);

    // Get the fleet specifications from the SetUpJson object.
    Map<ShipType, Integer> fleetSpecs = args.fleetSpec();

    // Call the setup() method of the player to get a list of ships for the fleet.
    List<Ship> fleet = player.setup(height, width, fleetSpecs);

    // A list of ShipJson objects to send back to the server.
    ArrayList<ShipJson> shipJsonsList = new ArrayList<>();

    // Loop through all ships in the fleet.
    for (Ship ship : fleet) {

      // Get the starting coordinate of the ship.
      Coord startCoord = ship.getShipCoords().get(0);

      // Determine the size of the ship based on its coordinates.
      int shipSize = ship.getShipCoords().size();

      // Get the ship's orientation.
      Orientation orientation = ship.getOrientation();

      // Create a CoordJson object from the start coordinate.
      CoordJson coordJson = new CoordJson(startCoord.getXvalue(), startCoord.getYvalue());

      // Create a ShipJson object from the CoordJson, size, and orientation.
      ShipJson shipJson = new ShipJson(coordJson, shipSize, orientation);

      // Add the ShipJson object to the list.
      shipJsonsList.add(shipJson);
    }
    // Create a FleetJson object from the list of ShipJson objects.
    FleetJson fleetJson = new FleetJson(shipJsonsList);

    // Convert the FleetJson object to a JsonNode.
    JsonNode jsonArgument = JsonUtils.serializeRecord(fleetJson);
    MessageJson messageJson = new MessageJson("setup", jsonArgument);

    // Convert the MessageJson object to a JsonNode.
    JsonNode jsonResponse = JsonUtils.serializeRecord(messageJson);

    // send the response back to the server
    this.out.println(jsonResponse);

  }

  /**
   * Handles the "take-shots" server message. The JsonNode arguments decide on the coordinates
   * where it wants to take shots.
   *
   * @param arguments - JsonNode arguments that are passed in
   */
  private void handleTakeShots(JsonNode arguments) {
    // Calls the takeShots() method from the Player class, which generates a list of coordinates
    // where the player wants to take a shot.
    List<Coord> shots = player.takeShots();

    // Create an ArrayList to hold CoordJson objects. Each Coord object will be
    // converted to a CoordJson object and added to this list.
    ArrayList<CoordJson> coordJsonsList = new ArrayList<>();

    // Iterate over each Coord object in the shots list.
    for (Coord coord : shots) {
      CoordJson coordJson = new CoordJson(coord.getXvalue(), coord.getYvalue());
      coordJsonsList.add(coordJson);
    }

    // Create a VolleyJson object from the list of CoordJson objects.
    VolleyJson volleyJson = new VolleyJson(coordJsonsList);

    // Convert the VolleyJson object to a JsonNode.
    JsonNode jsonArgument = JsonUtils.serializeRecord(volleyJson);

    // Create a new MessageJson object
    MessageJson messageJson = new MessageJson("take-shots", jsonArgument);

    // Convert the MessageJson object to a JsonNode
    JsonNode jsonResponse = JsonUtils.serializeRecord(messageJson);

    // Sends the shots taken to the server by printing them to the output stream

    this.out.println(jsonResponse);
  }


  /**
   * Handles the "report-damage" server message. The player receives a report of
   * damage from the shots it took in the last turn.
   *
   * @param arguments - Json Arguements that are passed in
   */
  private void handleReportDamage(JsonNode arguments) {
    // Convert JsonNode "arguments" to List<Coord> object using the ObjectMapper.
    VolleyJson shotsReceived = mapper.convertValue(arguments, VolleyJson.class);

    // Create an ArrayList to hold Coord objects.
    ArrayList<Coord> coordArrayList = new ArrayList<>();

    // Iterate over each CoordJson object in the shotsReceived list.
    for (CoordJson coordJson : shotsReceived.getCoordinates()) {
      // Create a new Coord object from each CoordJson object
      Coord coord = new Coord(coordJson.getX(), coordJson.getY());
      // Add the new Coord object to the coordArrayList.
      coordArrayList.add(coord);
    }

    // Calls the reportDamage() method from the Player class, which processes the shots received
    // and returns a list of hit coordinates.
    List<Coord> hitCoords = player.reportDamage(coordArrayList);

    // Convert the list of hit coordinates into a MessageJson object.
    MessageJson messageJson = listCoordToMessageJson("report-damage", hitCoords);

    // Convert the MessageJson object into a JsonNode
    JsonNode jsonResponse = JsonUtils.serializeRecord(messageJson);

    // Sends the shots taken to the server by printing them to the output stream
    this.out.println(jsonResponse);
  }

  /**
   * Handles the "successful-hits" server message. The player updates its feedback
   * board with the coordinates that successfully hit the opponent's ships.
   *
   * @param arguments -Json Arguments for the successful hits server Json
   */
  private void handleSuccessfulHits(JsonNode arguments) {
    // Convert JsonNode "arguments" to List<Coord> object using the ObjectMapper.
    VolleyJson successfulHits = mapper.convertValue(arguments, VolleyJson.class);

    ArrayList<Coord> coordArrayList = new ArrayList<>();
    for (CoordJson coordJson : successfulHits.getCoordinates()) {
      Coord coord = new Coord(coordJson.getX(), coordJson.getY());
      coordArrayList.add(coord);
    }

    // Calls the successfulHits() method from the Player class,
    // which updates the player's feedback board
    // with the coordinates that successfully hit the opponent's ships.
    player.successfulHits(coordArrayList);


    JsonNode jsonNode = mapper.createObjectNode();

    MessageJson messageJson = new MessageJson("successful-hits", jsonNode);

    // Convert the response Map to JsonNode.
    JsonNode response = JsonUtils.serializeRecord(messageJson);

    // Sends the response to the server.
    this.out.println(response);
  }

  /**
   * Handles the "end-game" server message. The player receives the game result
   * and the reason why the game ended.
   *
   * @param arguments - the Json Arguments for the end game method
   */
  private void handleEndGame(JsonNode arguments) {
    // Convert JsonNode "arguments" to a GameResult object
    GameResult result = GameResult.valueOf(mapper.convertValue(arguments.get("result"),
        String.class));
    String reason = mapper.convertValue(arguments.get("reason"), String.class);

    // Calls the endGame() method from the Player class, which ends the game.
    player.endGame(result, reason);


    JsonNode jsonNode = mapper.createObjectNode();

    MessageJson messageJson = new MessageJson("end-game", jsonNode);

    // Convert the response Map to JsonNode.
    JsonNode response = JsonUtils.serializeRecord(messageJson);

    // Sends the response to the server.
    this.out.println(response);
  }


  /**
   * Helper method which converts a list of coordinates to a message JSON
   * This can then be sent to the server.
   *
   * @param methodName - the method name to be included in the message JSON
   * @param listCoords - the list of coordinates to be converted into a message JSON
   * @return - the created message JSON
   */
  public MessageJson listCoordToMessageJson(String methodName, List<Coord> listCoords) {
    // Initialize an ArrayList of CoordJson objects
    ArrayList<CoordJson> coordJsonsList = new ArrayList<>();

    // Iterate over each Coord object in the list passed as argument.
    for (Coord coord : listCoords) {
      // Create a new CoordJson object using the x and y values from the Coord object.
      CoordJson coordJson = new CoordJson(coord.getXvalue(), coord.getYvalue());
      // Add the  CoordJson object to the coordJsonsList.
      coordJsonsList.add(coordJson);
    }

    // Create a new VolleyJson object using the list of CoordJson objects
    VolleyJson volleyJson = new VolleyJson(coordJsonsList);

    // Use the JsonUtils class to serialize the VolleyJson object into a JsonNode object.
    JsonNode jsonArgument = JsonUtils.serializeRecord(volleyJson);
    MessageJson messageJson = new MessageJson(methodName, jsonArgument);

    // Return the messageJson object
    return messageJson;
  }
}
