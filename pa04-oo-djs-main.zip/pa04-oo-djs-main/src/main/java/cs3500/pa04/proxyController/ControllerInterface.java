package cs3500.pa04.proxyController;

/**
 * Controller Interface
 */
public interface ControllerInterface {
  void run();

}
