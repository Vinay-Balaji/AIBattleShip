package cs3500.pa04;

import cs3500.pa03.controller.Controller;
import cs3500.pa04.json.GameType;
import cs3500.pa04.proxyController.ProxyController;
import java.io.IOException;
import java.net.Socket;

/**
 * This is the main driver of this project
 */
public class Driver {
  private static void runClient(String host, int port)
      throws IOException, IllegalStateException {
    Socket server = new Socket(host, port);
    ProxyController proxyDealer = new ProxyController(server, GameType.SINGLE);
    proxyDealer.run();
  }


  /**
   * Project entry point
   *
   * @param args - no command line args required
   */
  public static void main(String[] args) {
    if (args.length == 2) {
      String host = args[0];
      //String host = "0.0.0.0";
      int port = Integer.parseInt(args[1]);
      //int port = 35001;

      try {
        runClient(host, port);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    } else if (args.length == 0) {
      System.out.println("Hello from Battle Salvo - PA03 Template Repo");
      try {
        Controller controller = new Controller();
        controller.gameLoop();
      } catch (Exception exception) {
        System.err.println("error occurred");
        exception.printStackTrace();
      }
    } else {
      throw new RuntimeException("no arguments found");
    }

  }
}