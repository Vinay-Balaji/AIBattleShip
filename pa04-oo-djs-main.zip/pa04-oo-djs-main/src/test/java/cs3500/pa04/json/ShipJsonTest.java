package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa03.model.Orientation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests for the shipJson class
 */
class ShipJsonTest {

  ShipJson shipJson;

  /**
   * Runs this block of code before each test
   */
  @BeforeEach
  public void setUp() {
    this.shipJson = new ShipJson(new CoordJson(1, 2), 3, Orientation.HORIZONTAL);
  }

  /**
   * Tests the .getCoord() method
   */
  @Test
  public void getCoord() {
    assertEquals(new CoordJson(1, 2), this.shipJson.getCoord());
  }

  /**
   * Tests the .getLength() method
   */
  @Test
  public void getLength() {
    assertEquals(3, this.shipJson.getLength());
  }

  /**
   * Tests the .getDirection() method
   */
  @Test
  public void getDirection() {
    assertEquals(Orientation.HORIZONTAL, this.shipJson.getDirection());
  }

  /**
   * Tests the .coord() method
   */
  @Test
  public void coord() {
    assertEquals(new CoordJson(1, 2), this.shipJson.coord());
  }

  /**
   * Tests the .length()
   */
  @Test
  public void length() {
    assertEquals(3, this.shipJson.length());
  }

  /**
   * Tests the .direction()
   */
  @Test
  public void direction() {
    assertEquals(Orientation.HORIZONTAL, this.shipJson.direction());
  }
}