package cs3500.pa04.json;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test class for the PlayerJson class.
 */
class PlayerJsonTest {

  PlayerJson playerJson;

  /**
   * Runs this code before each test
   */
  @BeforeEach
  public void setUp() {
    this.playerJson = new PlayerJson("player", "SINGLE");
  }

  /**
   * Tests the .getName() method
   */
  @Test
  public void getName() {
    assertEquals("player", this.playerJson.getName());
  }

  /**
   * Tests the .getGameType() method
   */
  @Test
  public void getGameType() {
    assertEquals("SINGLE", this.playerJson.getGameType());
  }

  /**
   * Tests the .name() method
   */
  @Test
  public void name() {
    assertEquals("player", this.playerJson.name());
  }

  /**
   * Tests the .gameType() method
   */
  @Test
  public void gameType() {
    assertEquals("SINGLE", this.playerJson.gameType());
  }
}