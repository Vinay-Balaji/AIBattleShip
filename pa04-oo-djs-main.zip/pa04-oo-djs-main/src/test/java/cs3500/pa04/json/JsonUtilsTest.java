package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

/**
 * Test class for the JsonUtils utility class.
 */
class JsonUtilsTest {

  /**
   * Test case for the JsonUtil serializeRecord() method.
   */
  @Test
  public void serializeRecord() {
    //assertThrows(IllegalArgumentException.class, () -> JsonUtils.serializeRecord(null));
    JsonUtils jsonUtils = new JsonUtils();
    CoordJson coordJson = new CoordJson(1, 2);
    ObjectMapper mapper = new ObjectMapper();
    assertEquals(mapper.convertValue(coordJson, JsonNode.class),
        JsonUtils.serializeRecord(coordJson));
  }
}