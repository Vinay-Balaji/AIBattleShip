package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests the VolleyJson class
 */
class VolleyJsonTest {

  VolleyJson volleyJson;

  /**
   * Runs this block of code before each test
   */
  @BeforeEach
  public void setup() {
    CoordJson coordJson1 = new CoordJson(1, 2);
    CoordJson coordJson2 = new CoordJson(2, 3);
    CoordJson coordJson3 = new CoordJson(1, 4);
    List<CoordJson> coordJsonList =
        new ArrayList<>(Arrays.asList(coordJson1, coordJson2, coordJson3));
    this.volleyJson = new VolleyJson(coordJsonList);
  }

  /**
   * Tests for the .getCoordinates() method
   */
  @Test
  public void getCoordinates() {
    CoordJson coordJson1 = new CoordJson(1, 2);
    CoordJson coordJson2 = new CoordJson(2, 3);
    CoordJson coordJson3 = new CoordJson(1, 4);
    List<CoordJson> coordJsonList =
        new ArrayList<>(Arrays.asList(coordJson1, coordJson2, coordJson3));
    assertEquals(coordJsonList, this.volleyJson.getCoordinates());
  }

  /**
   * Tests for the .shots() method
   */
  @Test
  public void shots() {
    CoordJson coordJson1 = new CoordJson(1, 2);
    CoordJson coordJson2 = new CoordJson(2, 3);
    CoordJson coordJson3 = new CoordJson(1, 4);
    List<CoordJson> coordJsonList =
        new ArrayList<>(Arrays.asList(coordJson1, coordJson2, coordJson3));
    assertEquals(coordJsonList, this.volleyJson.shots());
  }
}