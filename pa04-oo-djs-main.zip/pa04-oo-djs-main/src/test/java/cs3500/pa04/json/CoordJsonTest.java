package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test class for the CoordJson class
 */
class CoordJsonTest {

  CoordJson coordJson;

  /**
   * Setup before each test case
   */
  @BeforeEach
  public void setUp() {
    coordJson = new CoordJson(1, 2);
  }

  /**
   * Test case for getX() method
   */
  @Test
  public void getX() {
    assertEquals(1, this.coordJson.getX());
  }

  /**
   * Test case for getY() method
   */
  @Test
  public void getY() {
    assertEquals(2, this.coordJson.getY());
  }

  /**
   * Test case for x() method
   */
  @Test
  public void testX() {
    assertEquals(1, this.coordJson.x());
  }

  /**
   * Test case for the y() method
   */
  @Test
  public void testY() {
    assertEquals(2, this.coordJson.y());
  }
}