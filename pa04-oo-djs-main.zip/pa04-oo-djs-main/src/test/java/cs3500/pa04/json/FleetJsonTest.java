package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa03.model.Orientation;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test class for the FleetJson class.
 */
class FleetJsonTest {

  FleetJson fleetJson;

  /**
   * Runs this setup before each test case
   */
  @BeforeEach
  public void setup() {
    ShipJson shipJson1 = new ShipJson(new CoordJson(1, 2), 3, Orientation.HORIZONTAL);
    ShipJson shipJson2 = new ShipJson(new CoordJson(2, 2), 2, Orientation.VERTICAL);
    ShipJson shipJson3 = new ShipJson(new CoordJson(3, 2), 4, Orientation.HORIZONTAL);
    ArrayList<ShipJson> shipJsons = new ArrayList<>(Arrays.asList(shipJson1, shipJson2, shipJson3));
    this.fleetJson = new FleetJson(shipJsons);
  }

  /**
   * Test case for the getFleet() method
   */
  @Test
  public void getFleet() {
    ShipJson shipJson1 = new ShipJson(new CoordJson(1, 2), 3, Orientation.HORIZONTAL);
    ShipJson shipJson2 = new ShipJson(new CoordJson(2, 2), 2, Orientation.VERTICAL);
    ShipJson shipJson3 = new ShipJson(new CoordJson(3, 2), 4, Orientation.HORIZONTAL);
    ArrayList<ShipJson> shipJsons = new ArrayList<>(Arrays.asList(shipJson1, shipJson2, shipJson3));
    assertEquals(shipJsons, this.fleetJson.getFleet());
  }

  /**
   * Test case for the fleet() method
   */
  @Test
  public void fleet() {
    ShipJson shipJson1 = new ShipJson(new CoordJson(1, 2), 3, Orientation.HORIZONTAL);
    ShipJson shipJson2 = new ShipJson(new CoordJson(2, 2), 2, Orientation.VERTICAL);
    ShipJson shipJson3 = new ShipJson(new CoordJson(3, 2), 4, Orientation.HORIZONTAL);
    ArrayList<ShipJson> shipJsons = new ArrayList<>(Arrays.asList(shipJson1, shipJson2, shipJson3));
    assertEquals(shipJsons, this.fleetJson.fleet());
  }
}