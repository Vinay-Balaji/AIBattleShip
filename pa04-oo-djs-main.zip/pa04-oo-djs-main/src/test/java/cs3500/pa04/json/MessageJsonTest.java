package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.Test;

/**
 * Test class for the MessageJson class.
 */
class MessageJsonTest {

  /**
   * Test case for the methodName() method
   */
  @Test
  public void methodName() {
    CoordJson coordJson = new CoordJson(1, 2);
    JsonNode jsonNode = JsonUtils.serializeRecord(coordJson);
    MessageJson messageJson = new MessageJson("hello", jsonNode);
    assertEquals("hello", messageJson.methodName());
  }

  /**
   * Test case for the arguments() method
   */
  @Test
  public void arguments() {
    CoordJson coordJson = new CoordJson(1, 2);
    JsonNode jsonNode = JsonUtils.serializeRecord(coordJson);
    MessageJson messageJson = new MessageJson("hello", jsonNode);
    assertEquals(jsonNode, messageJson.arguments());
  }
}