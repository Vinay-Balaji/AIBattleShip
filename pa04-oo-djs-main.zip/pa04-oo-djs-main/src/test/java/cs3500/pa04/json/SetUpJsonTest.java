package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa03.model.ShipType;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests for the setUpJson class
 */
class SetUpJsonTest {
  SetUpJson setUpJson;

  /**
   * Runs this before each other test
   */
  @BeforeEach
  public void setUp() {
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 2);


    this.setUpJson = new SetUpJson(3, 4, map);
  }

  /**
   * Tests for the .width() method
   */
  @Test
  public void width() {
    assertEquals(3, this.setUpJson.width());
  }

  /**
   * Tests for the .height() method
   */
  @Test
  public void height() {
    assertEquals(4, this.setUpJson.height());
  }

  /**
   * Tests for the .fleetSpec() method
   */
  @Test
  public void fleetSpec() {
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 2);
    assertEquals(map, this.setUpJson.fleetSpec());
  }
}