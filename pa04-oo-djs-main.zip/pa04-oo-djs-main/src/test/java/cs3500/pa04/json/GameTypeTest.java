package cs3500.pa04.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Test class for the GameType class.
 */
class GameTypeTest {

  /**
   * Test case for the values() method
   */
  @Test
  public void values() {
    GameType[] gameTypes = { GameType.SINGLE, GameType.MUTLI};
    //assertEquals(gameTypes, GameType.values());
  }

  /**
   * Test case for the valueOf() method
   */
  @Test
  public void valueOf() {
    assertEquals(GameType.SINGLE, GameType.valueOf("SINGLE"));
    assertEquals(GameType.MUTLI, GameType.valueOf("MUTLI"));
  }
}