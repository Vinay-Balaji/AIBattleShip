package cs3500.pa04.proxyController;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cs3500.pa03.model.Coord;
import cs3500.pa03.model.ShipType;
import cs3500.pa04.json.CoordJson;
import cs3500.pa04.json.GameType;
import cs3500.pa04.json.JsonUtils;
import cs3500.pa04.json.MessageJson;
import cs3500.pa04.json.PlayerJson;
import cs3500.pa04.json.SetUpJson;
import cs3500.pa04.json.VolleyJson;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProxyControllerTest {

  private ByteArrayOutputStream testLog;
  private ProxyController controller;


  /**
   * Reset the test log before each test is run.
   */
  @BeforeEach
  public void setup() {
    this.testLog = new ByteArrayOutputStream(2048);
    assertEquals("", logToString());
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleJoinTest() {
    // Prepare sample message

    JsonNode sampleMessage = createSampleMessage("join", null);

    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessage.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    this.controller.run();

    String expected = "{\"method-name\":\"join\",\"arguments\":{\"name\":"
        + "\"jackyu000\",\"game-type\":\"SINGLE\"}}";
    System.out.println(logToString());
    assertTrue(logToString().contains(expected));
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleSetUp() {
    // Prepare sample message
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 1);
    map.put(ShipType.BATTLESHIP, 1);

    SetUpJson setUpJson = new SetUpJson(6, 8, map);

    JsonNode sampleMessage = createSampleMessage("setup", setUpJson);


    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessage.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    this.controller.run();

    String setupPrefix = "{\"method-name\":\"setup\",\"arguments\":{\"fleet\":[{\"coord\":{\"x\":";
    assertTrue(logToString().contains(setupPrefix));
    assertTrue(logToString().contains("length"));
    assertTrue(logToString().contains("direction"));
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleTakeShotsTest() {
    // Prepare sample message
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 1);
    map.put(ShipType.BATTLESHIP, 1);

    SetUpJson setUpJson = new SetUpJson(6, 8, map);

    JsonNode sampleMessageSetup = createSampleMessage("setup", setUpJson);

    JsonNode sampleMessageTakeShots = createSampleMessage("take-shots", null);

    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessageSetup.toString(),
        sampleMessageTakeShots.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    this.controller.run();

    String takeShotsPrefix = "{\"method-name\":\"take-shots\","
        + "\"arguments\":{\"coordinates\":[{\"x\":";
    System.out.println(logToString());
    assertTrue(logToString().contains(takeShotsPrefix));
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleReportDamageTest() {
    // Prepare sample message
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 1);
    map.put(ShipType.BATTLESHIP, 1);

    SetUpJson setUpJson = new SetUpJson(6, 8, map);

    JsonNode sampleMessageSetup = createSampleMessage("setup", setUpJson);

    CoordJson coordJson1 = new CoordJson(1, 2);
    CoordJson coordJson2 = new CoordJson(2, 2);
    CoordJson coordJson3 = new CoordJson(1, 3);

    List<CoordJson> coordJsonList =
        new ArrayList<>(Arrays.asList(coordJson1, coordJson2, coordJson3));

    VolleyJson volleyJson = new VolleyJson(coordJsonList);

    JsonNode sampleMessageReportDamage =
        createSampleMessage("report-damage", volleyJson);

    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessageSetup.toString(),
        sampleMessageReportDamage.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    this.controller.run();

    String reportDamage = "{\"method-name\":\"report-damage\",\"arguments\":{\"coordinates\":[";
    System.out.println(logToString());
    assertTrue(logToString().contains(reportDamage));
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleSuccessfulHitsTest() {
    // Prepare sample message
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 1);
    map.put(ShipType.BATTLESHIP, 1);

    SetUpJson setUpJson = new SetUpJson(6, 8, map);

    JsonNode sampleMessageSetup = createSampleMessage("setup", setUpJson);

    CoordJson coordJson1 = new CoordJson(1, 2);
    CoordJson coordJson2 = new CoordJson(2, 2);
    CoordJson coordJson3 = new CoordJson(1, 3);

    List<CoordJson> coordJsonList =
        new ArrayList<>(Arrays.asList(coordJson1, coordJson2, coordJson3));

    VolleyJson volleyJson = new VolleyJson(coordJsonList);

    JsonNode sampleMessageReportDamage =
        createSampleMessage("successful-hits", volleyJson);

    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessageSetup.toString(),
        sampleMessageReportDamage.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    this.controller.run();

    String successfulHits = "{\"method-name\":\"successful-hits\",\"arguments\":{}}";
    System.out.println(logToString());
    assertTrue(logToString().contains(successfulHits));
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleEndGameTest() {
    // Prepare sample message
    Map<ShipType, Integer> map = new HashMap<>();
    map.put(ShipType.DESTROYER, 1);
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.SUBMARINE, 1);
    map.put(ShipType.BATTLESHIP, 1);

    SetUpJson setUpJson = new SetUpJson(6, 8, map);

    JsonNode sampleMessageSetup = createSampleMessage("setup", setUpJson);

    Map<String, String> endGame = new HashMap<>();
    endGame.put("result", "WIN");
    endGame.put("reason", "Player 1 sank all of Player 2's ships");
    ObjectMapper mapper = new ObjectMapper();
    JsonNode jsonNode = mapper.convertValue(endGame, JsonNode.class);

    MessageJson messageJson = new MessageJson("end-game", jsonNode);

    JsonNode sampleMessageEndGame = JsonUtils.serializeRecord(messageJson);

    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessageSetup.toString(),
        sampleMessageEndGame.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    this.controller.run();

    String endGameResult = "{\"method-name\":\"end-game\",\"arguments\":{}}";
    System.out.println(logToString());
    assertTrue(logToString().contains(endGameResult));
  }

  /**
   * Check that the server returns a guess when given a hint.
   */
  @Test
  public void handleExceptionTest() {
    // Prepare sample message

    JsonNode sampleMessage = createSampleMessage("hello", null);

    // Create the client with all necessary messages
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessage.toString()));

    // Create a Dealer
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the dealer can't be created
    }

    // run the dealer and verify the response
    assertThrows(IllegalStateException.class, () -> this.controller.run());
  }


  /**
   * Converts the ByteArrayOutputStream log to a string in UTF_8 format
   *
   * @return String representing the current log buffer
   *
   */
  private String logToString() {
    return testLog.toString(StandardCharsets.UTF_8);
  }

  /**
   * Try converting the current test log to a string of a certain class.
   *
   * @param classRef Type to try converting the current test stream to.
   * @param <T>      Type to try converting the current test stream to.
   */
  private <T> void responseToClass(@SuppressWarnings("SameParameterValue") Class<T> classRef) {
    try {
      JsonParser jsonParser = new ObjectMapper().createParser(logToString());
      jsonParser.readValueAs(classRef);
      // No error thrown when parsing to a GuessJson, test passes!
    } catch (IOException e) {
      // Could not read
      // -> exception thrown
      // -> test fails since it must have been the wrong type of response.
      fail();
    }
  }

  /**
   * Create a MessageJson for some name and arguments.
   *
   * @param messageName name of the type of message; "hint" or "win"
   * @param messageObject object to embed in a message json
   * @return a MessageJson for the object
   */
  private JsonNode createSampleMessage(String messageName, Record messageObject) {
    MessageJson messageJson = new MessageJson(messageName,
        JsonUtils.serializeRecord(messageObject));
    return JsonUtils.serializeRecord(messageJson);
  }


  /**
   * Tests for the listCoordToMessageJson() method
   */
  @Test
  public void listCoordToMessageJsonTest() {
    JsonNode sampleMessage = createSampleMessage("hello", null);
    Mocket socket = new Mocket(this.testLog, List.of(sampleMessage.toString()));

    // Create a controller
    try {
      this.controller = new ProxyController(socket, GameType.SINGLE);
    } catch (IOException e) {
      fail(); // fail if the controller can't be created
    }
    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(3, 2);
    List<Coord> coords = new ArrayList<>(Arrays.asList(coord1, coord2));
    CoordJson coordJson1 = new CoordJson(1, 2);
    CoordJson coordJson2 = new CoordJson(3, 2);
    List<CoordJson> coordJsons = new ArrayList<>(Arrays.asList(coordJson1, coordJson2));
    VolleyJson volleyJson = new VolleyJson(coordJsons);
    JsonNode jsonArgument = JsonUtils.serializeRecord(volleyJson);
    MessageJson messageJson = new MessageJson("take-shots", jsonArgument);

    assertEquals(messageJson, this.controller.listCoordToMessageJson("take-shots", coords));
  }
}