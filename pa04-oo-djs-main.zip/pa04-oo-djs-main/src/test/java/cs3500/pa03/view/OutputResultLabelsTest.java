package cs3500.pa03.view;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa03.model.GameResult;
import org.junit.jupiter.api.Test;

/**
 * Tests OutputResultLabels class
 */
class OutputResultLabelsTest {

  /**
   * Tests resultLabel method
   */
  @Test
  void resultLabelTest() {
    OutputResultLabels outputResultLabels = new OutputResultLabels();
    assertEquals(System.out.append("YOU WIN"), OutputResultLabels.resultLabel(GameResult.WIN));
    assertEquals(System.out.append("YOU LOSE"), OutputResultLabels.resultLabel(GameResult.LOSE));
    assertEquals(System.out.append("DRAW"), OutputResultLabels.resultLabel(GameResult.DRAW));
  }
}