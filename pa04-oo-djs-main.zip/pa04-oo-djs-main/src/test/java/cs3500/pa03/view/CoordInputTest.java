package cs3500.pa03.view;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import cs3500.pa03.model.Coord;
import java.io.StringReader;
import org.junit.jupiter.api.Test;

/**
 * Tests CoordInput class
 */
class CoordInputTest {

  /**
   * Tests receiveCoordInput method
   */
  @Test
  void receiveCoordInputTest() {
    CoordInput coordInput = new CoordInput(6, 9, 4, 4);

    Readable input1 = new StringReader("2");
    assertFalse(coordInput.receiveCoordInput(input1));

    Readable input2 = new StringReader("2 0 0");
    assertFalse(coordInput.receiveCoordInput(input2));

    Readable input3 = new StringReader("12 0");
    assertFalse(coordInput.receiveCoordInput(input3));

    Readable input4 = new StringReader("0 , 13");
    assertFalse(coordInput.receiveCoordInput(input4));

    Readable input6 = new StringReader("3 , 7");
    assertFalse(coordInput.receiveCoordInput(input6));

    Readable input7 = new StringReader("7 , 3");
    assertFalse(coordInput.receiveCoordInput(input7));

    Readable input8 = new StringReader("7 , 13");
    assertFalse(coordInput.receiveCoordInput(input8));

    Readable input9 = new StringReader("17 , 7");
    assertFalse(coordInput.receiveCoordInput(input9));

    Readable input10 = new StringReader("0 , 0");
    assertFalse(coordInput.receiveCoordInput(input10));

    Readable input11 = new StringReader("17 , 17");
    assertFalse(coordInput.receiveCoordInput(input11));

    Readable input5 = new StringReader("5 , 5");
    assertTrue(coordInput.receiveCoordInput(input5));

    assertEquals(new Coord(5, 5), coordInput.getCoord());
  }

  /**
   * Tests enterCoordsPrompt method
   */
  @Test
  void enterCoordsPromptTest() {
    CoordInput coordInput = new CoordInput(6, 9, 0, 0);
    assertEquals(System.out.append("Enter " + 6 + " coordinate pairs: \n"),
        coordInput.enterCoordsPrompt(6, false));
    assertEquals(System.out.append("Enter " + 6 + " coordinate pairs: \n"),
        coordInput.enterCoordsPrompt(6, true));
  }

  /**
   * Tests errorCoordsPrompt method
   */
  @Test
  void errorCoordsPromptTest() {
    CoordInput coordInput = new CoordInput(6, 9, 0, 0);
    assertEquals(System.out.append("Try Again Follow the Correct Format\n"),
        coordInput.errorCoordsPrompt());
  }
}