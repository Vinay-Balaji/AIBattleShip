package cs3500.pa03.view;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa03.model.Cell;
import cs3500.pa03.model.Status;
import org.junit.jupiter.api.Test;

/**
 * Tests OutputShipBoard class
 */
class OutputShipBoardTest {

  /**
   * Tests printShipBoard method
   */
  @Test
  void printShipBoardTest() {
    OutputResultLabels outputResultLabels = new OutputResultLabels();
    Cell cell00 = new Cell(Status.SHIP);
    Cell cell10 = new Cell(Status.MISS);
    Cell cell01 = new Cell(Status.HIT);
    Cell cell11 = new Cell(Status.EMPTY);
    Cell[] cells1 = {cell00, cell01};
    Cell[] cells2 = {cell10, cell11};
    Cell[][] cells2D = {cells1, cells2};
    assertEquals(System.out.append("S M \nH 0 \n"), OutputShipBoard.printShipBoard(cells2D));


  }
}