package cs3500.pa03.view;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * Tests ShipsInput class
 */
class ShipsInputTest {

  /**
   * Tests receiveShipInput method
   */
  @Test
  void receiveShipInputTest() {
    ShipsInput shipsInput = new ShipsInput();

    Readable input1 = new StringReader("2 d e d  2 5 e er t ");
    assertFalse(shipsInput.receiveShipInput(input1, 6, 6));

    Readable input2 = new StringReader("2 0 0 4 1");
    assertFalse(shipsInput.receiveShipInput(input2, 6, 6));

    Readable input3 = new StringReader("3             3 3 3");
    assertFalse(shipsInput.receiveShipInput(input3, 6, 6));

    Readable input5 = new StringReader("1 2 2 1");
    assertTrue(shipsInput.receiveShipInput(input5, 6, 8));
    List<Integer> integerList = new ArrayList<>(Arrays.asList(1, 2, 2, 1));
    assertEquals(integerList, shipsInput.getShipList());

    Readable input6 = new StringReader("3 3 3 3");
    assertFalse(shipsInput.receiveShipInput(input6, 6, 9));

    Readable input12 = new StringReader("2 2 2 2");
    assertFalse(shipsInput.receiveShipInput(input12, 7, 6));

    Readable input14 = new StringReader("2 2 2 2");
    assertFalse(shipsInput.receiveShipInput(input14, 6, 7));

    Readable input13 = new StringReader("0 2 2 2");
    assertFalse(shipsInput.receiveShipInput(input13, 3, 3));

    Readable input7 = new StringReader("0 0 2 1");
    assertFalse(shipsInput.receiveShipInput(input7, 4, 4));

    Readable input8 = new StringReader("1 0 2 1");
    assertFalse(shipsInput.receiveShipInput(input8, 4, 5));

    Readable input9 = new StringReader("1 2 0 1");
    assertFalse(shipsInput.receiveShipInput(input9, 4, 5));

    Readable input10 = new StringReader("1 1 2 0");
    assertFalse(shipsInput.receiveShipInput(input10, 5, 4));

    Readable input11 = new StringReader("0 0 0 0");
    assertFalse(shipsInput.receiveShipInput(input11, 3, 4));

    Readable input15 = new StringReader("2 2 2 3");
    assertFalse(shipsInput.receiveShipInput(input15, 10, 7));

    Readable input16 = new StringReader("1 1 2 2");
    assertFalse(shipsInput.receiveShipInput(input16, 10, 5));
  }
}