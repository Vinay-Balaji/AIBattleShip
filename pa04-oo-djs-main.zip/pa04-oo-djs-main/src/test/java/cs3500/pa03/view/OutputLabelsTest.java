package cs3500.pa03.view;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Tests OutputLabels class
 */
class OutputLabelsTest {

  /**
   * Tests printOpponentBoardLabel method
   */
  @Test
  void printOpponentBoardLabelTest() {
    OutputLabels outputLabels = new OutputLabels();
    assertEquals(System.out.append("Opponent Board Data:\n"),
        outputLabels.printOpponentBoardLabel());
  }

  /**
   * Tests printUserBoardLabel method
   */
  @Test
  void printUserBoardLabelTest() {
    assertEquals(System.out.append("Your Board:\n"), OutputLabels.printUserBoardLabel());
  }

  /**
   * Tests printBoardSizePrompt method
   */
  @Test
  void printBoardSizePromptTest() {
    assertEquals(System.out.append("Please enter a valid height and width below:\n"),
        OutputLabels.printBoardSizePrompt(false));
    assertEquals(System.out.append("Please enter a valid height and width below:\n"),
        OutputLabels.printBoardSizePrompt(true));
  }

  /**
   * Tests printInvalidBoardSizePrompt method
   */
  @Test
  void printInvalidBoardSizePromptTest() {
    assertEquals(System.out.append("Uh Oh! You've entered invalid dimensions."
            + " Please remember that the height and width\n"
            + "of the game must be in the range (6, 10), inclusive. Try again!\n"),
        OutputLabels.printInvalidBoardSizePrompt());
  }

  /**
   * Tests printFleetSizePrompt method
   */
  @Test
  void printFleetSizePromptTest() {
    assertEquals(System.out.append("Please enter your fleet in the order "
        + "[Carrier, Battleship, Destroyer, Submarine].\n"
        + "Remember, your fleet may not exceed size 8.\n"),
        OutputLabels.printFleetSizePrompt(false));
    assertEquals(System.out.append("Uh Oh! You've entered invalid fleet sizes."
            + "\nPlease enter your fleet in the order "
            + "[Carrier, Battleship, Destroyer, Submarine].\n"
            + "Remember, your fleet may not exceed size 8.\n"),
        OutputLabels.printFleetSizePrompt(true));
  }

  /**
   * Tests printInvalidFleetSizePrompt method
   */
  @Test
  void printInvalidFleetSizePromptTest() {
    assertEquals(System.out.append("Uh Oh! You've entered invalid fleet sizes.\n"),
        OutputLabels.printInvalidFleetSizePrompt());
  }
}