package cs3500.pa03.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import cs3500.pa03.model.Coord;
import cs3500.pa03.model.GameResult;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ControllerTest {

  Controller controller;

  @BeforeEach
  void setUp() {
    this.controller = new Controller();
    this.controller.initialization(6, 6, 1, 1, 1, 1);
  }

  @Test
  void gameLoop() {
    assertThrows(RuntimeException.class, () -> this.controller.gameLoop());
  }

  @Test
  void turn() {
    assertThrows(RuntimeException.class, () -> this.controller.turn());
  }

  @Test
  void initialization() {
  }

  @Test
  void checkEndNotEnd() {
    assertFalse(this.controller.checkEnd());
  }

  @Test
  void checkEndLose() {
    ArrayList<Coord> coords = new ArrayList<>();
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        coords.add(new Coord(i, j));
      }
    }
    this.controller.humanPlayer.reportDamage(coords);
    assertTrue(this.controller.checkEnd());
  }

  @Test
  void checkEndNotWin() {
    ArrayList<Coord> coords = new ArrayList<>();
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        coords.add(new Coord(i, j));
      }
    }
    this.controller.computerPlayer.reportDamage(coords);
    assertTrue(this.controller.checkEnd());
  }

  @Test
  void checkEndNotDraw() {
    ArrayList<Coord> coords = new ArrayList<>();
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        coords.add(new Coord(i, j));
      }
    }
    this.controller.humanPlayer.reportDamage(coords);
    this.controller.humanPlayer.reportDamage(coords);
    assertTrue(this.controller.checkEnd());
  }

  @Test
  void gameResultLose() {
    assertThrows(RuntimeException.class, () -> this.controller.gameResult());
    ArrayList<Coord> coords = new ArrayList<>();
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        coords.add(new Coord(i, j));
      }
    }
    this.controller.humanPlayer.reportDamage(coords);
    assertEquals(GameResult.LOSE, this.controller.gameResult());
  }

  @Test
  void gameResultWin() {
    assertThrows(RuntimeException.class, () -> this.controller.gameResult());
    ArrayList<Coord> coords = new ArrayList<>();
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        coords.add(new Coord(i, j));
      }
    }
    this.controller.computerPlayer.reportDamage(coords);
    assertEquals(GameResult.WIN, this.controller.gameResult());
  }

  @Test
  void gameResultDraw() {
    assertThrows(RuntimeException.class, () -> this.controller.gameResult());
    ArrayList<Coord> coords = new ArrayList<>();
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        coords.add(new Coord(i, j));
      }
    }
    this.controller.humanPlayer.reportDamage(coords);
    this.controller.computerPlayer.reportDamage(coords);
    assertEquals(GameResult.DRAW, this.controller.gameResult());
  }
}