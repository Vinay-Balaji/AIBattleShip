package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import cs3500.pa03.view.CoordInput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests HumanPlayer object
 */
class HumanPlayerTest {
  HumanPlayer humanPlayer;

  /**
   * Initializes the object
   */
  @BeforeEach
  void setUp() {
    this.humanPlayer = new HumanPlayer(8, 9,
        new CoordInput(8, 9, 0, 0));
  }

  /**
   * Tests name method
   */
  @Test
  void nameTest() {
    assertEquals("HUMAN", this.humanPlayer.name());
  }

  /**
   * Tests setUp method
   */
  @Test
  void setupTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    List<Ship> arrayList = this.humanPlayer.setup(8, 9, map);
    assertEquals(this.humanPlayer.getShipList(), arrayList);
    Cell[][] shipCells = this.humanPlayer.getShipBoardData();
    assertEquals(9, shipCells[0].length);
    assertEquals(8, shipCells.length);
    Cell[][] feedbackCells = this.humanPlayer.getFeedbackBoardData();
    assertEquals(9, feedbackCells[0].length);
    assertEquals(8, feedbackCells.length);
    for (Cell[] cellList : feedbackCells) {
      for (Cell cell : cellList) {
        assertEquals(Status.EMPTY, cell.getStatus());
      }
    }
  }

  /**
   * Tests takeShots method
   */
  @Test
  void takeShotsTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.humanPlayer.setup(8, 9, map);
    assertThrows(NoSuchElementException.class,  () ->  this.humanPlayer.takeShots());
  }

  /**
   * Tests reportDamage method
   */
  @Test
  void reportDamageTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.humanPlayer.setup(8, 9, map);

    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(2, 2);
    Coord coord3 = new Coord(3, 2);
    Coord coord4 = new Coord(0, 2);
    ArrayList<Coord> shotArrayList = new ArrayList<>(Arrays.asList(coord1, coord2, coord3, coord4));

    Cell[][]shipBoardData = this.humanPlayer.getShipBoardData();
    Status status1 = shipBoardData[2][1].getStatus();
    Status status2 = shipBoardData[2][2].getStatus();
    Status status3 = shipBoardData[2][3].getStatus();
    final Status status4 = shipBoardData[2][0].getStatus();

    final List<Coord> shotHitActual = this.humanPlayer.reportDamage(shotArrayList);
    Cell[][]shipBoardDataResult = this.humanPlayer.getShipBoardData();
    ArrayList<Coord> shotsHitExpected = new ArrayList<>();

    if (status1.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][1].getStatus());
      shotsHitExpected.add(new Coord(1, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][1].getStatus());
    }
    if (status2.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][2].getStatus());
      shotsHitExpected.add(new Coord(2, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][2].getStatus());
    }
    if (status3.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][3].getStatus());
      shotsHitExpected.add(new Coord(3, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][3].getStatus());
    }
    if (status4.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][0].getStatus());
      shotsHitExpected.add(new Coord(0, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][0].getStatus());
    }
    assertEquals(shotsHitExpected, shotHitActual);

    ArrayList<Coord> shotArrayListAll = new ArrayList<>();
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 9; j++) {
        shotArrayListAll.add(new Coord(j, i));
      }
    }
    this.humanPlayer.reportDamage(shotArrayListAll);
    assertTrue(this.humanPlayer.getShipList().isEmpty());


  }

  /**
   * Tests successfulHits method
   */
  @Test
  void successfulHitsTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.humanPlayer.setup(8, 9, map);

    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(2, 2);
    Coord coord3 = new Coord(3, 2);
    Coord coord4 = new Coord(4, 2);

    ArrayList<Coord> shotHitArrayList = new ArrayList<>(Arrays.asList(coord1, coord2));
    ArrayList<Coord> shotAllArrayList =
        new ArrayList<>(Arrays.asList(coord1, coord2, coord3, coord4));
    this.humanPlayer.shots = shotAllArrayList;
    this.humanPlayer.successfulHits(shotHitArrayList);


    Cell[][] feedbackBoardData = this.humanPlayer.getFeedbackBoardData();
    assertEquals(Status.HIT, feedbackBoardData[2][1].getStatus());
    assertEquals(Status.HIT, feedbackBoardData[2][2].getStatus());
    assertEquals(Status.MISS, feedbackBoardData[2][3].getStatus());
    assertEquals(Status.MISS, feedbackBoardData[2][4].getStatus());
    assertEquals(Status.EMPTY, feedbackBoardData[0][0].getStatus());

  }

  /**
   * Tests endGame method
   */
  @Test
  void endGameTest() {
    this.humanPlayer.endGame(GameResult.WIN, "hello");
  }
}