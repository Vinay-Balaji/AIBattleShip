package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests ComputerPlayer class
 */
class ComputerPlayerTest {
  ComputerPlayer computerPlayer;

  /**
   * Initializes the object
   */
  @BeforeEach
  void setUp() {
    this.computerPlayer = new ComputerPlayer(8, 9);
  }

  /**
   * Tests name method
   */
  @Test
  void nameTest() {
    assertEquals("COMPUTER", this.computerPlayer.name());
  }

  /**
   * Tests setUp method
   */
  @Test
  void setupTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    List<Ship> arrayList = this.computerPlayer.setup(8, 9, map);
    assertEquals(this.computerPlayer.getShipList(), arrayList);
    Cell[][] shipCells = this.computerPlayer.getShipBoardData();
    assertEquals(9, shipCells[0].length);
    assertEquals(8, shipCells.length);
    Cell[][] feedbackCells = this.computerPlayer.getFeedbackBoardData();
    assertEquals(9, feedbackCells[0].length);
    assertEquals(8, feedbackCells.length);
    for (Cell[] cellList : feedbackCells) {
      for (Cell cell : cellList) {
        assertEquals(Status.EMPTY, cell.getStatus());
      }
    }
  }

  /**
   * Tests takeShots method
   */
  @Test
  void takeShotsTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.computerPlayer.setup(8, 9, map);
    List<Coord> round1 = this.computerPlayer.takeShots();
    List<Coord> round2 = this.computerPlayer.takeShots();
    List<Coord> round3 = this.computerPlayer.takeShots();
    List<Coord> round4 = this.computerPlayer.takeShots();
    for (Coord coord : round1) {
      assertFalse(round2.contains(coord));
    }
    for (Coord coord : round2) {
      assertFalse(round3.contains(coord));
    }
    for (Coord coord : round3) {
      assertFalse(round4.contains(coord));
    }
    for (Coord coord : round4) {
      assertFalse(round1.contains(coord));
    }
    this.computerPlayer.takeShots();
    this.computerPlayer.takeShots();
    this.computerPlayer.takeShots();

  }

  /**
   * Tests reportDamage method
   */
  @Test
  void reportDamageTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.computerPlayer.setup(8, 9, map);

    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(2, 2);
    Coord coord3 = new Coord(3, 2);
    Coord coord4 = new Coord(0, 2);
    ArrayList<Coord> shotArrayList = new ArrayList<>(Arrays.asList(coord1, coord2, coord3, coord4));

    Cell[][]shipBoardData = this.computerPlayer.getShipBoardData();
    Status status1 = shipBoardData[2][1].getStatus();
    Status status2 = shipBoardData[2][2].getStatus();
    Status status3 = shipBoardData[2][3].getStatus();
    final Status status4 = shipBoardData[2][0].getStatus();

    final List<Coord> shotHitActual = this.computerPlayer.reportDamage(shotArrayList);
    Cell[][]shipBoardDataResult = this.computerPlayer.getShipBoardData();
    ArrayList<Coord> shotsHitExpected = new ArrayList<>();

    if (status1.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][1].getStatus());
      shotsHitExpected.add(new Coord(1, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][1].getStatus());
    }
    if (status2.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][2].getStatus());
      shotsHitExpected.add(new Coord(2, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][2].getStatus());
    }
    if (status3.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][3].getStatus());
      shotsHitExpected.add(new Coord(3, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][3].getStatus());
    }
    if (status4.equals(Status.SHIP)) {
      assertEquals(Status.HIT, shipBoardDataResult[2][0].getStatus());
      shotsHitExpected.add(new Coord(0, 2));
    } else {
      assertEquals(Status.MISS, shipBoardDataResult[2][0].getStatus());
    }
    assertEquals(shotsHitExpected, shotHitActual);

    ArrayList<Coord> shotArrayListAll = new ArrayList<>();
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 9; j++) {
        shotArrayListAll.add(new Coord(j, i));
      }
    }
    this.computerPlayer.reportDamage(shotArrayListAll);
    assertTrue(this.computerPlayer.getShipList().isEmpty());


  }

  /**
   * Tests successfulHits method
   */
  @Test
  void successfulHitsTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.computerPlayer.setup(8, 9, map);

    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(2, 2);
    Coord coord3 = new Coord(3, 2);
    Coord coord4 = new Coord(4, 2);

    ArrayList<Coord> shotHitArrayList = new ArrayList<>(Arrays.asList(coord1, coord2));
    ArrayList<Coord> shotAllArrayList =
        new ArrayList<>(Arrays.asList(coord1, coord2, coord3, coord4));
    this.computerPlayer.shots = shotAllArrayList;
    this.computerPlayer.successfulHits(shotHitArrayList);


    Cell[][] feedbackBoardData = this.computerPlayer.getFeedbackBoardData();
    assertEquals(Status.HIT, feedbackBoardData[2][1].getStatus());
    assertEquals(Status.HIT, feedbackBoardData[2][2].getStatus());
    assertEquals(Status.MISS, feedbackBoardData[2][3].getStatus());
    assertEquals(Status.MISS, feedbackBoardData[2][4].getStatus());
    assertEquals(Status.EMPTY, feedbackBoardData[0][0].getStatus());

  }
  /**
   * Tests takeShots method when getTargetedShot returns null
   */

  @Test
  void takeShotsTest_whenGetTargetedShotReturnsNull() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.computerPlayer.setup(8, 9, map);

    // Add all shots to successfulShots list to make getTargetedShot return null
    List<Coord> allPossibleShots = new ArrayList<>();
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 9; j++) {
        allPossibleShots.add(new Coord(j, i));
      }
    }
    this.computerPlayer.successfulShots.addAll(allPossibleShots);

    List<Coord> roundShots = this.computerPlayer.takeShots();

    assertTrue(allPossibleShots.containsAll(roundShots), "Test");
  }

  /**
   * Tests takeShots method when getTargetedShot returns non-null
   */
  @Test
  void takeShotsTest_whenGetTargetedShotReturnsNonNull() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    this.computerPlayer.setup(8, 9, map);

    // Add one successful shot to the list
    Coord successfulShot = new Coord(1, 1);
    this.computerPlayer.successfulShots.add(successfulShot);

    List<Coord> roundShots = this.computerPlayer.takeShots();

    assertFalse(roundShots.contains(successfulShot), "Test");
  }


  /**
   * Tests endGame method
   */
  @Test
  void endGameTest() {
    this.computerPlayer.endGame(GameResult.WIN, "1");
    this.computerPlayer.endGame(GameResult.LOSE, "2");
    this.computerPlayer.endGame(GameResult.DRAW, "3");
  }

}