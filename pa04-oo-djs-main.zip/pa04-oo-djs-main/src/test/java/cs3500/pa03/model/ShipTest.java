package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * Tests Ship class
 */
class ShipTest {

  /**
   * Tests addListCoord method
   */
  @Test
  void addListCoordTest() {
    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(2, 2);
    Coord coord3 = new Coord(3, 2);
    Coord coord4 = new Coord(0, 2);
    ArrayList<Coord> coordArrayList1 = new ArrayList<>(Arrays.asList(coord1, coord2));
    ArrayList<Coord> coordArrayList2 = new ArrayList<>(Arrays.asList(coord3, coord4));
    ArrayList<Coord> coordArrayList3 = new ArrayList<>();
    coordArrayList3.addAll(coordArrayList1);
    coordArrayList3.addAll(coordArrayList2);
    Ship ship = new Ship(Orientation.HORIZONTAL);
    ship.addListCoord(coordArrayList1);

    assertEquals(coordArrayList1, ship.getShipCoords());

    ship.addListCoord(coordArrayList2);
    assertEquals(coordArrayList3, ship.getShipCoords());

  }

  /**
   * Tests removeCoord method
   */
  @Test
  void removeCoordTest() {
    Coord coord1 = new Coord(1, 2);
    Coord coord2 = new Coord(2, 2);
    ArrayList<Coord> coordArrayList1 = new ArrayList<>(Arrays.asList(coord1, coord2));
    Ship ship = new Ship(Orientation.HORIZONTAL);
    ship.addListCoord(coordArrayList1);
    assertEquals(coordArrayList1, ship.getShipCoords());
    ship.removeCoord(new Coord(1, 2));
    assertEquals(new ArrayList<>(List.of(coord2)), ship.getShipCoords());
    ship.removeCoord(new Coord(0, 0));
    assertEquals(new ArrayList<>(List.of(coord2)), ship.getShipCoords());
  }

  /**
   * Tests getOrientation() method of the Ship class.
   */
  @Test
  void getOrientationTest() {
    Ship shipHorizontal = new Ship(Orientation.HORIZONTAL);
    Ship shipVertical = new Ship(Orientation.VERTICAL);

    assertEquals(Orientation.HORIZONTAL, shipHorizontal.getOrientation(), "horizontal");
    assertEquals(Orientation.VERTICAL, shipVertical.getOrientation(), "vertical");
  }
}