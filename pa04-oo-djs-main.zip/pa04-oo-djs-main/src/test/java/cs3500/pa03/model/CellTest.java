package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests Cell class
 */
class CellTest {

  Cell empty;
  Cell hit;
  Cell miss;

  /**
   * Initializes objects
   */
  @BeforeEach
  void setUpTest() {
    this.empty = new Cell();
    this.hit = new Cell(Status.HIT);
    this.miss = new Cell(Status.MISS);

  }

  /**
   * Tests setHit method
   */
  @Test
  void setHitTest() {
    this.empty.setHit();
    this.hit.setHit();
    this.miss.setHit();
    assertEquals(Status.HIT, this.empty.getStatus());
    assertEquals(Status.HIT, this.hit.getStatus());
    assertEquals(Status.HIT, this.miss.getStatus());
  }

  /**
   * Tests setMiss method
   */
  @Test
  void setMissTest() {
    this.empty.setMiss();
    this.hit.setMiss();
    this.miss.setMiss();
    assertEquals(Status.MISS, this.empty.getStatus());
    assertEquals(Status.MISS, this.hit.getStatus());
    assertEquals(Status.MISS, this.miss.getStatus());
  }

}