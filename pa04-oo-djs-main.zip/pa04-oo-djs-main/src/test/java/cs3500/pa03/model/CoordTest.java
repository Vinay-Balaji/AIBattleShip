package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests Coord class
 */
class CoordTest {

  Coord coord1;
  Coord coord2;
  Coord coord3;

  /**
   * Initializes Coord Objects
   */
  @BeforeEach
  void setUp() {
    this.coord1 = new Coord(0, 0);
    this.coord2 = new Coord(1, 2);
    this.coord3 = new Coord(0, 0);
  }

  /**
   * Tests getX method
   */
  @Test
  void getXcoordTest() {
    assertEquals(0, this.coord1.getXvalue());
    assertEquals(1, this.coord2.getXvalue());
  }

  /**
   * Tests getY method
   */
  @Test
  void getYcoordTest() {
    assertEquals(0, this.coord1.getYvalue());
    assertEquals(2, this.coord2.getYvalue());
  }

  /**
   * Tests testEquals method
   */
  @Test
  void testEqualsTest() {
    assertTrue(this.coord1.equals(this.coord3));
    assertFalse(this.coord1.equals("hi"));
    assertTrue(this.coord1.equals(this.coord1));
  }
}