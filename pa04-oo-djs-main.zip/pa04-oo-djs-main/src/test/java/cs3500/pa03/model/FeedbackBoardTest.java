package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests FeedbackBoard class
 */
class FeedbackBoardTest {

  FeedbackBoard feedbackBoard;

  /**
   * Initializes Coord Objects
   */
  @BeforeEach
  void setUp() {
    this.feedbackBoard = new FeedbackBoard(2, 2);
  }

  /**
   * Tests etUp method
   */
  @Test
  void setUpTest() {
    this.feedbackBoard.setUp();
    Cell[][] cells = this.feedbackBoard.getFeedbackBoard();
    assertEquals(2, cells.length);
    assertEquals(2, cells[0].length);
    assertEquals(Status.EMPTY, cells[0][0].getStatus());
    assertEquals(Status.EMPTY, cells[0][1].getStatus());
    assertEquals(Status.EMPTY, cells[1][0].getStatus());
    assertEquals(Status.EMPTY, cells[1][1].getStatus());
  }

  /**
   * Tests updateShots method
   */
  @Test
  void updateShotsTest() {
    this.feedbackBoard.setUp();
    Coord coord1 = new Coord(0, 0);
    Coord coord2 = new Coord(1, 0);
    ArrayList<Coord> all = new ArrayList<>(Arrays.asList(coord2, coord1));
    ArrayList<Coord> hit = new ArrayList<>(Arrays.asList(coord1));

    this.feedbackBoard.updateShots(hit, all);
    Cell[][] cells = this.feedbackBoard.getFeedbackBoard();

    assertEquals(Status.HIT, cells[0][0].getStatus());
    assertEquals(Status.MISS, cells[0][1].getStatus());
    assertEquals(Status.EMPTY, cells[1][0].getStatus());
    assertEquals(Status.EMPTY, cells[1][1].getStatus());
  }
}