package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

/**
 * Tests ShipList clas
 */
class ShipListTest {

  /**
   * Tests generateShipsPositionList method
   */
  @Test
  void generateShipsPositionListTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    ShipList shipBoard = new ShipList(10, 10, map);
    ShipList shipList = new ShipList(7, 7, map);
    shipList.generateShipsPositionList();

    shipBoard.generateShipsPositionList();
    ArrayList<Coord> listShipCoords = shipBoard.getShipPositions();


    for (int i = 0; i < 5; i++) {
      assertTrue((listShipCoords.get(i).getXvalue() == listShipCoords.get(i + 1).getXvalue())
          || (listShipCoords.get(i).getYvalue() == listShipCoords.get(i + 1).getYvalue()));
    }

    for (int i = 6; i < 10; i++) {
      assertTrue((listShipCoords.get(i).getXvalue() == listShipCoords.get(i + 1).getXvalue())
          || (listShipCoords.get(i).getYvalue() == listShipCoords.get(i + 1).getYvalue()));
    }

    for (int i = 11; i < 15; i++) {
      assertTrue((listShipCoords.get(i).getXvalue() == listShipCoords.get(i + 1).getXvalue())
          || (listShipCoords.get(i).getYvalue() == listShipCoords.get(i + 1).getYvalue()));
    }

    for (int i = 16; i < 19; i++) {
      assertTrue((listShipCoords.get(i).getXvalue() == listShipCoords.get(i + 1).getXvalue())
          || (listShipCoords.get(i).getYvalue() == listShipCoords.get(i + 1).getYvalue()));
    }

    for (int i = 20; i < 23; i++) {
      assertTrue((listShipCoords.get(i).getXvalue() == listShipCoords.get(i + 1).getXvalue())
          || (listShipCoords.get(i).getYvalue() == listShipCoords.get(i + 1).getYvalue()));
    }

    for (int i = 24; i < 26; i++) {
      assertTrue((listShipCoords.get(i).getXvalue() == listShipCoords.get(i + 1).getXvalue())
          || (listShipCoords.get(i).getYvalue() == listShipCoords.get(i + 1).getYvalue()));
    }


    for (Coord coord : listShipCoords) {
      int timesSeen = 0;
      for (Coord coord1 : listShipCoords) {
        if (coord.getYvalue() == coord1.getYvalue() && coord.getXvalue() == coord1.getXvalue()) {
          timesSeen++;
        }
      }
      assertTrue(timesSeen == 1);
      assertTrue(coord.getYvalue() < 10);
      assertTrue(coord.getXvalue() < 10);
    }

  }

  /**
   * Tests generateShipList method
   */
  @Test
  void generateShipListTest() {
    Map<ShipType, Integer> map = new HashMap<ShipType, Integer>();
    map.put(ShipType.CARRIER, 1);
    map.put(ShipType.BATTLESHIP, 2);
    map.put(ShipType.DESTROYER, 2);
    map.put(ShipType.SUBMARINE, 1);
    ShipList shipBoard = new ShipList(10, 10, map);
    shipBoard.generateShipList(ShipType.CARRIER, 1);
    ArrayList<Coord> coordArrayList = shipBoard.getShipList().get(0).getShipCoords();
    for (int i = 0; i < 5; i++) {
      assertTrue((coordArrayList.get(i).getXvalue() == coordArrayList.get(i + 1).getXvalue())
          || (coordArrayList.get(i).getYvalue() == coordArrayList.get(i + 1).getYvalue()));
    }

  }

}