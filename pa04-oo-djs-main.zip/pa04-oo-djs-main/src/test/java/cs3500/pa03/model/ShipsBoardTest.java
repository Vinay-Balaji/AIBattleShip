package cs3500.pa03.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests ShipsBoard class
 */
class ShipsBoardTest {
  ShipsBoard shipsBoard;

  /**
   * Initializes objects
   */
  @BeforeEach
  void setUp() {
    Coord coord = new Coord(0, 0);
    Coord coord1 = new Coord(1, 0);
    ArrayList<Coord> coordArrayList = new ArrayList<>(Arrays.asList(coord1, coord));
    this.shipsBoard = new ShipsBoard(2, 2, coordArrayList);
  }

  /**
   * Tests setSelfVersionBoard method
   */
  @Test
  void setSelfVersionBoardTest() {
    this.shipsBoard.setSelfVersionBoard();
    Cell[][] cells = this.shipsBoard.getSelfVersionBoard();
    assertEquals(Status.SHIP, cells[0][0].getStatus());
    assertEquals(Status.SHIP, cells[0][1].getStatus());
    assertEquals(Status.EMPTY, cells[1][0].getStatus());
    assertEquals(Status.EMPTY, cells[1][1].getStatus());
  }

  /**
   * Tests hasShip method
   */
  @Test
  void hasShipTest() {
    this.shipsBoard.setSelfVersionBoard();
    assertTrue(this.shipsBoard.hasShip(new Coord(0, 0)));
    assertFalse(this.shipsBoard.hasShip(new Coord(1, 1)));
  }

  /**
   * Tests receiveShots method
   */
  @Test
  void receiveShotsTest() {
    Coord coord1 = new Coord(0, 0);
    Coord coord3 = new Coord(0, 1);


    ArrayList<Coord> coordArrayList = new ArrayList<>(Arrays.asList(coord1, coord3));
    this.shipsBoard.setSelfVersionBoard();
    this.shipsBoard.receiveShots(coordArrayList);
    Cell[][] cells = this.shipsBoard.getSelfVersionBoard();
    assertEquals(Status.HIT, cells[0][0].getStatus());
    assertEquals(Status.SHIP, cells[0][1].getStatus());
    assertEquals(Status.MISS, cells[1][0].getStatus());
    assertEquals(Status.EMPTY, cells[1][1].getStatus());
  }
}