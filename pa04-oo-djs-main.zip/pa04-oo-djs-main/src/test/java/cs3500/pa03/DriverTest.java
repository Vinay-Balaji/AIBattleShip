package cs3500.pa03;

import static org.junit.jupiter.api.Assertions.assertThrows;

import cs3500.pa04.Driver;
import org.junit.jupiter.api.Test;

/**
 * Tests Driver class
 */
class DriverTest {

  /**
   * Tests main method
   */
  @Test
  public void mainErrorTest() {
    Driver driver = new Driver();
    System.out.println("An important message...");
    String[] strings = new String[1];
    strings[0] = "hello";
    assertThrows(RuntimeException.class, () -> driver.main(strings));
  }

}